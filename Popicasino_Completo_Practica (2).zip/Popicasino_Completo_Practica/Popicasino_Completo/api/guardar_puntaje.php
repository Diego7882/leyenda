<?php
declare(strict_types=1); session_start(); header('Content-Type: application/json; charset=utf-8'); header('X-Content-Type-Options: nosniff');
require __DIR__.'/../config/database.php';
if($_SERVER['REQUEST_METHOD']!=='POST'){http_response_code(405);echo json_encode(['error'=>'Método no permitido']);exit;}
$data=json_decode(file_get_contents('php://input'),true)??[];
$csrf=$_SERVER['HTTP_X_CSRF_TOKEN']??'';
if(!hash_equals($_SESSION['csrf']??'', $csrf)){http_response_code(403);echo json_encode(['error'=>'Sesión inválida']);exit;}
$juego=(string)($data['juego']??'');$puntaje=filter_var($data['puntaje']??null,FILTER_VALIDATE_INT);
$permitidos=['gallo-de-oro','pampa-fortune','tango-reels','mega-popi','sierra-gold','noche-de-treboles','condor-real','malbec-wilds','crash-rocket','tiro-al-blanco','torre-popi','mina-segura','plinko','duelo-1-contra-1','ruleta-europea','ruleta-americana','blackjack','baccarat','poker-caribeno','dados-sic-bo'];
if(!in_array($juego,$permitidos,true)||$puntaje===false||$puntaje<0||$puntaje>1000000){http_response_code(422);echo json_encode(['error'=>'Resultado inválido']);exit;}
try{$pdo->beginTransaction();if(empty($_SESSION['jugador_id'])){$pdo->exec("INSERT INTO jugadores_demo (alias) VALUES ('Jugador de práctica')");$_SESSION['jugador_id']=(int)$pdo->lastInsertId();}
$id=(int)$_SESSION['jugador_id'];$q=$pdo->prepare('INSERT INTO resultados_juegos (jugador_id,juego,puntaje) VALUES (?,?,?)');$q->execute([$id,$juego,$puntaje]);$q=$pdo->prepare('UPDATE jugadores_demo SET puntos_totales=puntos_totales+?, partidas=partidas+1 WHERE id=?');$q->execute([$puntaje,$id]);$pdo->commit();echo json_encode(['ok'=>true,'puntaje'=>$puntaje]);}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();http_response_code(500);echo json_encode(['error'=>'No se pudo guardar el resultado']);}
