<?php
declare(strict_types=1); session_start(); header('Content-Type: application/json; charset=utf-8'); require __DIR__.'/../config/database.php';
if(empty($_SESSION['jugador_id'])){echo json_encode(['partidas'=>0,'puntos'=>0,'historial'=>[]]);exit;}
$id=(int)$_SESSION['jugador_id'];$q=$pdo->prepare('SELECT puntos_totales,partidas FROM jugadores_demo WHERE id=?');$q->execute([$id]);$res=$q->fetch()?:['puntos_totales'=>0,'partidas'=>0];$q=$pdo->prepare('SELECT juego,puntaje,creado_en FROM resultados_juegos WHERE jugador_id=? ORDER BY id DESC LIMIT 30');$q->execute([$id]);echo json_encode(['puntos'=>(int)$res['puntos_totales'],'partidas'=>(int)$res['partidas'],'historial'=>$q->fetchAll()]);
