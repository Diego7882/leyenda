<?php
/* Inicio de sesión: compara la contraseña escrita con el hash guardado (password_verify). */
require __DIR__ . '/config.php';
solo_post();
$d = entrada();

$email = strtolower(trim((string) ($d['mail'] ?? '')));
$pass  = (string) ($d['pass'] ?? '');

// Freno simple contra adivinar contraseñas: 5 errores seguidos = 30 s de espera
if (($_SESSION['bloqueo_hasta'] ?? 0) > time()) {
    throw new ErrorNegocio('Demasiados intentos. Esperá ' . ($_SESSION['bloqueo_hasta'] - time()) . ' segundos.');
}

$pdo = db();
$q = $pdo->prepare('SELECT id, password_hash FROM usuarios WHERE email = ?');
$q->execute([$email]);
$u = $q->fetch();

// Si el email no existe igual se verifica contra un hash falso (mismo tiempo de respuesta)
$hash = $u['password_hash'] ?? '$2y$10$usesomesillystringforsaltuOnlyDummyHashValueXXXXXXXXXXXXXXx';
$ok = password_verify($pass, $hash) && $u;

if (!$ok) {
    $_SESSION['fallos'] = ($_SESSION['fallos'] ?? 0) + 1;
    if ($_SESSION['fallos'] >= 5) { $_SESSION['bloqueo_hasta'] = time() + 30; $_SESSION['fallos'] = 0; }
    throw new ErrorNegocio('Email o contraseña incorrectos.');
}

// Si PHP mejora el algoritmo en el futuro, el hash se actualiza solo
if (password_needs_rehash($u['password_hash'], PASSWORD_BCRYPT)) {
    $r = $pdo->prepare('UPDATE usuarios SET password_hash = ? WHERE id = ?');
    $r->execute([password_hash($pass, PASSWORD_BCRYPT), $u['id']]);
}

$_SESSION['fallos'] = 0;
session_regenerate_id(true);
$_SESSION['uid'] = (int) $u['id'];
responder(['ok' => true]);
