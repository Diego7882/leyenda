<?php
/* Depósitos y retiros (SIMULADOS: no mueven dinero real). */
require __DIR__ . '/config.php';
solo_post();
$uid = exigir_sesion();
$d = entrada();
$pdo = db();

$accion = (string) ($d['accion'] ?? '');
$metodo = (string) ($d['metodo'] ?? '');
$metodos = ['transferencia', 'billetera', 'tarjeta'];
if (!in_array($metodo, $metodos, true)) throw new ErrorNegocio('Elegí un medio de pago.');

$codigo = ($accion === 'deposito' ? 'DEP-' : 'RET-') . strtoupper(bin2hex(random_bytes(4)));

$pdo->beginTransaction();
try {
    if ($accion === 'deposito') {
        $monto = entero($d['monto'] ?? null, 500, 5000000, 'El depósito va de $500 a $5.000.000.');
        $i = $pdo->prepare("INSERT INTO transacciones (usuario_id, tipo, metodo, monto, destino, codigo, estado, creado) VALUES (?,?,?,?,NULL,?,'acreditado',?)");
        $i->execute([$uid, 'deposito', $metodo, $monto, $codigo, ahora()]);
        $saldo = aplicar($pdo, $uid, 'deposito', 'Depósito ' . $codigo . ' (' . $metodo . ')', $monto);
        $estado = 'acreditado';
    } elseif ($accion === 'retiro') {
        $monto = entero($d['monto'] ?? null, 1000, 5000000, 'El retiro va de $1.000 a $5.000.000.');
        $destino = trim((string) ($d['destino'] ?? ''));
        if (!preg_match('/^\d{22}$/', $destino) && !preg_match('/^[A-Za-z0-9.\-]{6,20}$/', $destino)) {
            throw new ErrorNegocio('Ingresá un CBU/CVU de 22 números o un alias de 6 a 20 caracteres.');
        }
        $saldo = aplicar($pdo, $uid, 'retiro', 'Retiro ' . $codigo . ' (' . $metodo . ')', -$monto);
        $i = $pdo->prepare("INSERT INTO transacciones (usuario_id, tipo, metodo, monto, destino, codigo, estado, creado) VALUES (?,?,?,?,?,?,'procesando',?)");
        $i->execute([$uid, 'retiro', $metodo, $monto, $destino, $codigo, ahora()]);
        $estado = 'procesando';
    } else {
        throw new ErrorNegocio('Acción inválida.');
    }
    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    throw $e;
}

responder(['ok' => true, 'saldo' => $saldo, 'codigo' => $codigo, 'estado' => $estado, 'monto' => $monto, 'metodo' => $metodo, 'fecha' => ahora()]);
