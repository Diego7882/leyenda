<?php
/* Popicasino - configuración común de la API (XAMPP, localhost) */
declare(strict_types=1);
date_default_timezone_set('America/Argentina/Buenos_Aires');

const DB_HOST = 'localhost';
const DB_NAME = 'popicasino';
const DB_USER = 'root';   // usuario por defecto de XAMPP
const DB_PASS = '';       // contraseña por defecto de XAMPP: vacía

session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax']);
session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

class ErrorNegocio extends Exception {}

function db(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
    }
    return $pdo;
}

function responder(array $datos, int $codigo = 200): void {
    http_response_code($codigo);
    echo json_encode($datos, JSON_UNESCAPED_UNICODE);
    exit;
}

set_exception_handler(function (Throwable $e) {
    if ($e instanceof ErrorNegocio) {
        responder(['ok' => false, 'error' => $e->getMessage()], 400);
    }
    error_log('[Popicasino] ' . $e->getMessage());
    responder(['ok' => false, 'error' => 'Error del servidor. ¿Está Apache/MySQL encendido y la base importada (sql/popicasino.sql)?'], 500);
});

/** Lee el cuerpo JSON de la petición (o $_POST como alternativa). */
function entrada(): array {
    $crudo = file_get_contents('php://input');
    $json = $crudo ? json_decode($crudo, true) : null;
    return is_array($json) ? $json : $_POST;
}

function solo_post(): void {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        responder(['ok' => false, 'error' => 'Método no permitido'], 405);
    }
}

function exigir_sesion(): int {
    if (empty($_SESSION['uid'])) {
        responder(['ok' => false, 'error' => 'Sesión vencida. Volvé a iniciar sesión.', 'sesion' => false], 401);
    }
    return (int) $_SESSION['uid'];
}

function ahora(): string { return date('Y-m-d H:i:s'); }

function entero($v, int $min, int $max, string $msg): int {
    if (!is_numeric($v) || (float) $v != floor((float) $v)) throw new ErrorNegocio($msg);
    $n = (int) $v;
    if ($n < $min || $n > $max) throw new ErrorNegocio($msg);
    return $n;
}

/**
 * Suma o resta saldo de forma atómica (una sola sentencia UPDATE, no deja
 * que el saldo quede negativo) y registra el movimiento. Devuelve el saldo nuevo.
 */
function aplicar(PDO $pdo, int $uid, string $tipo, string $detalle, int $monto): int {
    if ($monto !== 0) {
        $u = $pdo->prepare('UPDATE usuarios SET saldo = saldo + ? WHERE id = ? AND saldo + ? >= 0');
        $u->execute([$monto, $uid, $monto]);
        if ($u->rowCount() !== 1) throw new ErrorNegocio('No tenés saldo suficiente.');
    }
    $s = $pdo->prepare('SELECT saldo FROM usuarios WHERE id = ?');
    $s->execute([$uid]);
    $saldo = (int) $s->fetchColumn();
    $m = $pdo->prepare('INSERT INTO movimientos (usuario_id, tipo, detalle, monto, saldo_despues, creado) VALUES (?,?,?,?,?,?)');
    $m->execute([$uid, $tipo, mb_substr($detalle, 0, 200), $monto, $saldo, ahora()]);
    return $saldo;
}

function saldo_de(PDO $pdo, int $uid): int {
    $s = $pdo->prepare('SELECT saldo FROM usuarios WHERE id = ?');
    $s->execute([$uid]);
    return (int) $s->fetchColumn();
}
