<?php
/* Devuelve el usuario logueado. Con {"completo": true} suma movimientos y transacciones. */
require __DIR__ . '/config.php';
$uid = exigir_sesion();
$d = entrada();
$pdo = db();

// Simulación: los retiros "procesando" pasan a "completado" a los 20 segundos
$c = $pdo->prepare("UPDATE transacciones SET estado = 'completado' WHERE usuario_id = ? AND estado = 'procesando' AND creado < ?");
$c->execute([$uid, date('Y-m-d H:i:s', time() - 20)]);

$q = $pdo->prepare('SELECT nombre, apellido, email, saldo FROM usuarios WHERE id = ?');
$q->execute([$uid]);
$u = $q->fetch();
if (!$u) { $_SESSION = []; responder(['ok' => false, 'error' => 'Usuario inexistente', 'sesion' => false], 401); }
$u['saldo'] = (int) $u['saldo'];
$res = ['ok' => true, 'usuario' => $u];

if (!empty($d['completo'])) {
    $m = $pdo->prepare('SELECT tipo, detalle, monto, creado FROM movimientos WHERE usuario_id = ? ORDER BY id DESC LIMIT 40');
    $m->execute([$uid]);
    $res['movimientos'] = array_map(fn($r) => ['tipo' => $r['tipo'], 'txt' => $r['detalle'], 'monto' => (int) $r['monto'], 'f' => $r['creado']], $m->fetchAll());

    $t = $pdo->prepare('SELECT tipo, metodo, monto, destino, codigo, estado, creado FROM transacciones WHERE usuario_id = ? ORDER BY id DESC LIMIT 20');
    $t->execute([$uid]);
    $res['transacciones'] = array_map(fn($r) => $r + ['monto' => (int) $r['monto']], $t->fetchAll());
}
responder($res);
