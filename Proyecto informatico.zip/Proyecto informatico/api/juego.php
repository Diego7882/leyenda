<?php
/* Apuestas de los juegos: "start" descuenta la apuesta, "end" acredita el premio. */
require __DIR__ . '/config.php';
solo_post();
$uid = exigir_sesion();
$d = entrada();
$pdo = db();

// Premio máximo permitido por juego (múltiplo de la apuesta)
const MAX_MULT = ['blackjack' => 2, 'cuentas' => 8, 'pollo' => 200, 'memoria' => 2, 'minas' => 120, 'crash' => 100];
const NOMBRES  = ['blackjack' => 'Blackjack', 'cuentas' => 'Cuentas rápidas', 'pollo' => 'Pollo en la avenida',
                  'memoria' => 'Memoria de pares', 'minas' => 'Mina segura', 'crash' => 'Crash rocket'];
const APUESTA_MAX = 1000000;

$accion = (string) ($d['accion'] ?? '');
$pdo->beginTransaction();
try {
    if ($accion === 'start') {
        $juego = (string) ($d['juego'] ?? '');
        if (!isset(MAX_MULT[$juego])) throw new ErrorNegocio('Juego inexistente.');
        $apuesta = entero($d['apuesta'] ?? null, 100, APUESTA_MAX, 'La apuesta va de $100 a $1.000.000.');

        // Si quedó una ronda abierta (cerraron la pestaña), se cierra como perdida
        $x = $pdo->prepare("UPDATE rondas SET estado = 'cerrada', cerrado = ? WHERE usuario_id = ? AND estado = 'abierta'");
        $x->execute([ahora(), $uid]);

        $saldo = aplicar($pdo, $uid, 'apuesta', 'Apuesta: ' . NOMBRES[$juego], -$apuesta);
        $r = $pdo->prepare("INSERT INTO rondas (usuario_id, juego, apuesta, pago, estado, creado) VALUES (?,?,?,0,'abierta',?)");
        $r->execute([$uid, $juego, $apuesta, ahora()]);
        $res = ['ok' => true, 'ronda' => (int) $pdo->lastInsertId(), 'saldo' => $saldo];

    } elseif ($accion === 'end') {
        $id = entero($d['ronda'] ?? null, 1, PHP_INT_MAX, 'Ronda inválida.');
        $q = $pdo->prepare("SELECT juego, apuesta FROM rondas WHERE id = ? AND usuario_id = ? AND estado = 'abierta'");
        $q->execute([$id, $uid]);
        $ronda = $q->fetch();
        if (!$ronda) throw new ErrorNegocio('Esa ronda ya está cerrada.');

        $apuesta = (int) $ronda['apuesta'];
        $pago = entero($d['pago'] ?? 0, 0, PHP_INT_MAX, 'Premio inválido.');
        if ($pago > $apuesta * MAX_MULT[$ronda['juego']]) throw new ErrorNegocio('Premio fuera de lo permitido.');

        // Se cierra primero (así no se puede cobrar dos veces la misma ronda)
        $c = $pdo->prepare("UPDATE rondas SET estado = 'cerrada', pago = ?, cerrado = ? WHERE id = ? AND estado = 'abierta'");
        $c->execute([$pago, ahora(), $id]);
        if ($c->rowCount() !== 1) throw new ErrorNegocio('Esa ronda ya está cerrada.');

        $saldo = $pago > 0
            ? aplicar($pdo, $uid, 'premio', 'Premio: ' . NOMBRES[$ronda['juego']], $pago)
            : saldo_de($pdo, $uid);
        $res = ['ok' => true, 'saldo' => $saldo, 'pago' => $pago];

    } elseif ($accion === 'deportes') {
        $monto = entero($d['monto'] ?? null, 100, APUESTA_MAX, 'La apuesta va de $100 a $1.000.000.');
        $detalle = trim((string) ($d['detalle'] ?? ''));
        $saldo = aplicar($pdo, $uid, 'deportes', 'Apuesta: ' . ($detalle ?: 'deportiva'), -$monto);
        $res = ['ok' => true, 'saldo' => $saldo];

    } else {
        throw new ErrorNegocio('Acción inválida.');
    }
    $pdo->commit();
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    throw $e;
}
responder($res);
