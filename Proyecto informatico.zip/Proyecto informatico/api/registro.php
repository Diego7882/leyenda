<?php
/* Registro: valida, guarda la contraseña ENCRIPTADA (bcrypt) e inicia sesión. */
require __DIR__ . '/config.php';
solo_post();
$d = entrada();

$nombre   = trim((string) ($d['nombre'] ?? ''));
$apellido = trim((string) ($d['apellido'] ?? ''));
$dni      = trim((string) ($d['dni'] ?? ''));
$nac      = trim((string) ($d['nac'] ?? ''));
$email    = strtolower(trim((string) ($d['mail'] ?? '')));
$pass     = (string) ($d['pass'] ?? '');

if (mb_strlen($nombre) < 2 || mb_strlen($nombre) > 60)     throw new ErrorNegocio('Ingresá tu nombre.');
if (mb_strlen($apellido) < 2 || mb_strlen($apellido) > 60) throw new ErrorNegocio('Ingresá tu apellido.');
if (!preg_match('/^\d{7,8}$/', $dni))                      throw new ErrorNegocio('El DNI tiene 7 u 8 números.');
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 120) throw new ErrorNegocio('Email inválido.');
if (strlen($pass) < 6)                                     throw new ErrorNegocio('La contraseña necesita mínimo 6 caracteres.');
if (strlen($pass) > 72)                                    throw new ErrorNegocio('La contraseña puede tener hasta 72 caracteres.');

$f = DateTime::createFromFormat('Y-m-d', $nac);
if (!$f || $f->format('Y-m-d') !== $nac)                   throw new ErrorNegocio('Fecha de nacimiento inválida.');
if ($f->diff(new DateTime('today'))->y < 18)               throw new ErrorNegocio('Error, tenés que ser mayor de 18 años para registrarte.');

$pdo = db();
$hash = password_hash($pass, PASSWORD_BCRYPT);   // <- lo único que llega a la base de datos

try {
    $q = $pdo->prepare('INSERT INTO usuarios (nombre, apellido, dni, fecha_nac, email, password_hash, saldo, creado) VALUES (?,?,?,?,?,?,0,?)');
    $q->execute([$nombre, $apellido, $dni, $nac, $email, $hash, ahora()]);
} catch (PDOException $e) {
    if ($e->getCode() === '23000') {
        $existe = $pdo->prepare('SELECT 1 FROM usuarios WHERE email = ?');
        $existe->execute([$email]);
        throw new ErrorNegocio($existe->fetchColumn() ? 'Ese email ya tiene una cuenta. Iniciá sesión.' : 'Ese DNI ya está registrado.');
    }
    throw $e;
}

session_regenerate_id(true);
$_SESSION['uid'] = (int) $pdo->lastInsertId();
responder(['ok' => true]);
