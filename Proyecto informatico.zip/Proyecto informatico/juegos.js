/* Popicasino: juegos (3 de casino + 3 de arcade).
   Cada juego recibe un contexto (ctx) desde app.js:
     ctx.saldo()                -> saldo actual
     ctx.iniciar(juego, apuesta)-> descuenta la apuesta en la base de datos y devuelve el id de ronda
     ctx.cerrar(ronda, pago)    -> acredita el premio en la base de datos
   Todo el azar usa crypto.getRandomValues (no Math.random). */
(() => {
'use strict';
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const sleep = ms => new Promise(r => setTimeout(r, ms));

/* ---------- Azar ---------- */
const rnd = n => { // entero 0..n-1 sin sesgo
  const a = new Uint32Array(1), lim = Math.floor(4294967296 / n) * n; let x;
  do { crypto.getRandomValues(a); x = a[0]; } while (x >= lim);
  return x % n;
};
const rango = (a, b) => a + rnd(b - a + 1);
const rfloat = () => { const a = new Uint32Array(1); crypto.getRandomValues(a); return a[0] / 4294967296; };
const shuffle = arr => { const a = [...arr]; for (let i = a.length - 1; i > 0; i--) { const j = rnd(i + 1); [a[i], a[j]] = [a[j], a[i]]; } return a; };

/* ---------- Panel de fichas (se muestra ABAJO, antes de cada partida) ---------- */
const FICHAS = [100, 200, 500, 1000, 5000, 10000];
const MAX_APUESTA = 1000000;
const ultima = {};
const corto = v => v >= 1000 ? (v / 1000) + 'K' : String(v);

function panelApuesta(host, ctx, juego, o) {
  // o = { boton, pago(bet) -> texto, onGo(bet), resultado? {tipo, titulo, detalle} }
  let bet = Math.min(ultima[juego] || 0, ctx.saldo());
  if (bet < 100) bet = 0;
  const r = o.resultado;
  host.innerHTML = `${r ? `<div class="resu ${r.tipo}" role="status"><b>${ctx.esc(r.titulo)}</b><span>${ctx.esc(r.detalle || '')}</span></div>` : ''}
    <div class="apuesta">
      <div class="ap-top"><div><small>Tu apuesta</small><b class="ap-val">${ctx.fmt(bet)}</b></div>
        <div class="ap-pago"><small>Si ganás cobrás</small><b>${o.pago(bet)}</b></div>
        <div class="ap-saldo"><small>Tu saldo</small><b>${ctx.fmt(ctx.saldo())}</b></div></div>
      <div class="fichas" role="group" aria-label="Fichas de apuesta">
        ${FICHAS.map(v => `<button type="button" class="ficha f${v}" data-v="${v}" aria-label="Sumar ${ctx.fmt(v)}"><span>${corto(v)}</span></button>`).join('')}
      </div>
      <div class="ap-act">
        <button type="button" class="btn ghost sm" data-a="borrar">Borrar</button>
        <button type="button" class="btn ghost sm" data-a="max">Todo el saldo</button>
        <button type="button" class="btn go" data-a="go">${o.boton}</button>
      </div>
      <p class="ap-nota">Tocá las fichas para sumar a tu apuesta. Mínimo ${ctx.fmt(100)}. Si el saldo no alcanza, <button type="button" class="link" data-a="dep">depositá</button>.</p>
    </div>`;
  const val = $('.ap-val', host), pago = $('.ap-pago b', host), go = $('[data-a=go]', host);
  const pintar = () => {
    val.textContent = ctx.fmt(bet);
    pago.textContent = o.pago(bet);
    go.disabled = bet < 100 || bet > ctx.saldo();
    $$('.ficha', host).forEach(f => f.disabled = bet + (+f.dataset.v) > Math.min(ctx.saldo(), MAX_APUESTA));
  };
  host.onclick = e => {
    const f = e.target.closest('.ficha'), a = e.target.closest('[data-a]');
    if (f) { bet += +f.dataset.v; pintar(); return; }
    if (!a) return;
    if (a.dataset.a === 'borrar') { bet = 0; pintar(); }
    else if (a.dataset.a === 'max') { bet = Math.min(Math.floor(ctx.saldo() / 100) * 100, MAX_APUESTA); pintar(); }
    else if (a.dataset.a === 'dep') ctx.depositar();
    else if (a.dataset.a === 'go' && bet >= 100 && bet <= ctx.saldo()) {
      ultima[juego] = bet; host.onclick = null; host.innerHTML = ''; o.onGo(bet);
    }
  };
  pintar();
}
const clasif = (bet, pago, fmt) =>
  pago > bet ? {tipo: 'gano', titulo: `¡Ganaste ${fmt(pago - bet)}!`, detalle: `Cobraste ${fmt(pago)} en total.`}
  : pago === bet ? {tipo: 'empate', titulo: 'Empate', detalle: `Recuperás tu apuesta de ${fmt(bet)}.`}
  : pago > 0 ? {tipo: 'perdio', titulo: `Cobraste ${fmt(pago)}`, detalle: `Perdiste ${fmt(bet - pago)} de tu apuesta.`}
  : {tipo: 'perdio', titulo: `Perdiste ${fmt(bet)}`, detalle: 'Suerte en la próxima.'};

/* =====================================================================
   CASINO 1: BLACKJACK  (gana x2: apostás 10.000 y cobrás 20.000)
   ===================================================================== */
function blackjack(el, ctx) {
  let vivo = true;
  const PALOS = ['♠', '♥', '♦', '♣'], RANGOS = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
  const valor = r => r === 'A' ? 11 : ['J', 'Q', 'K', '10'].includes(r) ? 10 : +r;
  const total = m => { let t = 0, a = 0; for (const c of m) { t += valor(c.r); if (c.r === 'A') a++; } while (t > 21 && a) { t -= 10; a--; } return t; };
  const nuevoMazo = () => { const m = []; for (let d = 0; d < 6; d++) for (const s of PALOS) for (const r of RANGOS) m.push({r, s}); return shuffle(m); };

  el.innerHTML = `<div class="mesa">
    <div class="zona"><div class="ztit">Crupier <span class="pts" id="dp"></span></div><div class="mano" id="dh"></div></div>
    <div class="mensaje" id="msg">Elegí tu apuesta con las fichas de abajo y tocá “Repartir”.</div>
    <div class="zona"><div class="ztit">Vos <span class="pts" id="pp"></span></div><div class="mano" id="ph"></div></div>
    <div class="acciones" id="acc"></div></div><div id="apuesta" class="zona-apuesta"></div>`;
  const host = $('#apuesta', el), msg = $('#msg', el), acc = $('#acc', el);

  const caraHTML = c => `<b>${c.r}</b><i>${c.s}</i><em>${c.s}</em>`;
  function crearCarta(c, oculta) {
    const d = document.createElement('div');
    d.className = 'carta entra' + ((c.s === '♥' || c.s === '♦') ? ' roja' : '') + (oculta ? ' oculta' : '');
    d.innerHTML = `<div class="cara">${oculta ? '' : caraHTML(c)}</div><div class="dorso"></div>`;
    return d;
  }
  function montar(resultado) {
    acc.innerHTML = '';
    panelApuesta(host, ctx, 'blackjack', {boton: 'Repartir', resultado,
      pago: b => b >= 100 ? ctx.fmt(b * 2) : '—', onGo: jugar});
  }
  async function jugar(bet) {
    let ronda;
    try { ronda = await ctx.iniciar('blackjack', bet); } catch (e) { ctx.toast(e.message); montar(); return; }
    if (!vivo) return;
    const mazo = nuevoMazo(), jug = [], cas = [];
    const dh = $('#dh', el), ph = $('#ph', el), dp = $('#dp', el), pp = $('#pp', el);
    dh.innerHTML = ph.innerHTML = ''; dp.textContent = pp.textContent = ''; acc.innerHTML = '';
    msg.textContent = `Apuesta en juego: ${ctx.fmt(bet)}. La casa reparte…`;
    let oculta = null;

    const dar = async (mano, cont, oc = false) => {
      const c = mazo.pop(); mano.push(c);
      const e = crearCarta(c, oc); cont.append(e);
      if (oc) oculta = {c, e};
      await sleep(520);
    };
    const pts = () => { pp.textContent = total(jug); dp.textContent = oculta ? '?' : total(cas); };
    const revelar = async () => {
      if (!oculta) return;
      $('.cara', oculta.e).innerHTML = caraHTML(oculta.c);
      oculta.e.classList.remove('oculta'); oculta.e.classList.add('giro');
      oculta = null; pts(); await sleep(650);
    };
    const terminar = async (pago, titulo) => {
      await revelar(); pts();
      try { await ctx.cerrar(ronda, pago); } catch (e) { ctx.toast(e.message); }
      if (!vivo) return;
      msg.textContent = titulo;
      montar(clasif(bet, pago, ctx.fmt));
    };

    // Reparto de a una carta: vos, casa (cara arriba), vos, casa (cara abajo)
    await dar(jug, ph); pts();
    await dar(cas, dh); pts();
    await dar(jug, ph); pts();
    await dar(cas, dh, true); pts();
    if (!vivo) return;

    const bjJug = total(jug) === 21, bjCas = total(cas) === 21;
    if (bjJug || bjCas) {
      if (bjJug && bjCas) return terminar(bet, 'Los dos tienen Blackjack: empate.');
      if (bjJug) return terminar(bet * 2, '¡Blackjack! Cobrás x2.');
      return terminar(0, 'La casa tiene Blackjack.');
    }

    const turnoCasa = async () => {
      acc.innerHTML = ''; msg.textContent = 'La casa da vuelta su carta…';
      await revelar();
      while (total(cas) < 17) { msg.textContent = 'La casa pide carta…'; await dar(cas, dh); pts(); if (!vivo) return; }
      const j = total(jug), c = total(cas);
      if (c > 21) return terminar(bet * 2, `La casa se pasó con ${c}. ¡Ganaste!`);
      if (j > c) return terminar(bet * 2, `${j} contra ${c}. ¡Ganaste!`);
      if (j === c) return terminar(bet, `${j} contra ${c}. Empate.`);
      return terminar(0, `${j} contra ${c}. Gana la casa.`);
    };
    const turnoJugador = () => {
      msg.textContent = `Tenés ${total(jug)}. ¿Pedís otra carta o te plantás? (Las cartas de la casa siguen tapadas.)`;
      acc.innerHTML = `<button class="btn" id="pedir">Pedir carta</button><button class="btn ghost" id="plantar">Plantarme</button>`;
      $('#pedir', el).onclick = async () => {
        acc.querySelectorAll('button').forEach(b => b.disabled = true);
        await dar(jug, ph); pts(); if (!vivo) return;
        const t = total(jug);
        if (t > 21) return terminar(0, `Te pasaste con ${t}.`);
        if (t === 21) return turnoCasa();
        turnoJugador();
      };
      $('#plantar', el).onclick = () => { acc.querySelectorAll('button').forEach(b => b.disabled = true); turnoCasa(); };
    };
    turnoJugador();
  }
  montar();
  return () => { vivo = false; };
}

/* =====================================================================
   CASINO 2: CUENTAS RÁPIDAS  (10 niveles, 7 segundos, 5 opciones)
   ===================================================================== */
const MULT_CUENTAS = [0.3, 0.5, 0.8, 1.1, 1.5, 2, 3, 4.5, 6, 8];
const SEGUNDOS = 7;
function generarCuenta(nivel) {
  let txt, res;
  switch (nivel) {
    case 1: { const x = rango(3, 9), y = rango(3, 9); txt = `${x} + ${y}`; res = x + y; break; }
    case 2: { const x = rango(12, 40), y = rango(3, 12);
      if (rnd(2)) { txt = `${x} + ${y + 8}`; res = x + y + 8; } else { txt = `${x} − ${y}`; res = x - y; } break; }
    case 3: { const x = rango(3, 9), y = rango(3, 9); txt = `${x} × ${y}`; res = x * y; break; }
    case 4: { const x = rango(25, 70), y = rango(16, 48);
      if (rnd(2)) { txt = `${x} + ${y}`; res = x + y; } else { txt = `${x + y} − ${y}`; res = x; } break; }
    case 5: { const x = rango(6, 12), y = rango(4, 9), z = rango(3, 25);
      if (rnd(2)) { txt = `${x} × ${y} + ${z}`; res = x * y + z; } else { txt = `${x} × ${y} − ${z}`; res = x * y - z; if (res < 0) { txt = `${x} × ${y} + ${z}`; res = x * y + z; } } break; }
    case 6: { const x = rango(12, 19), y = rango(3, 9); txt = `${x} × ${y}`; res = x * y; break; }
    case 7: { const x = rango(3, 9), y = rango(4, 9), z = rango(3, 9), w = rango(4, 9);
      txt = `${x} × ${y} + ${z} × ${w}`; res = x * y + z * w; break; }
    case 8: { const x = rango(6, 19), y = rango(6, 19), z = rango(3, 9); txt = `(${x} + ${y}) × ${z}`; res = (x + y) * z; break; }
    case 9: { const d = rango(3, 9), q = rango(6, 15), x = rango(3, 9), y = rango(4, 9);
      txt = `${d * q} ÷ ${d} + ${x} × ${y}`; res = q + x * y; break; }
    default: { const x = rango(13, 19), y = rango(12, 19), z = rango(5, 40);
      if (rnd(2)) { txt = `${x} × ${y}`; res = x * y; } else { txt = `${x} × ${y} − ${z}`; res = x * y - z; } }
  }
  // 4 distractores creíbles (errores típicos)
  const cand = shuffle([res + 1, res - 1, res + 2, res - 2, res + 10, res - 10, res + 5, res - 5, res + 3, res - 3, res + 20, res - 20, res + 11, res - 11]);
  const set = new Set(); for (const c of cand) { if (c > 0 && c !== res && set.size < 4) set.add(c); }
  let k = 30; while (set.size < 4) { set.add(res + (k++)); }
  return {txt, res, opciones: shuffle([res, ...set])};
}

function cuentas(el, ctx) {
  let vivo = true, timer = 0;
  el.innerHTML = `<div class="cuentas">
    <ol class="escalera" id="esc">${MULT_CUENTAS.map((m, i) => `<li data-n="${i + 1}"><span>Nivel ${i + 1}</span><b>x${m}</b></li>`).reverse().join('')}</ol>
    <div class="pregunta-box"><div class="cinfo" id="cinfo">Elegí tu apuesta y empezá. Tenés ${SEGUNDOS} segundos por cuenta.</div>
      <div class="tiempo"><i id="barra"></i></div>
      <div class="cuenta" id="cuenta">?</div>
      <div class="opciones" id="ops"></div>
      <div class="acciones" id="acc"></div></div></div>
    <div id="apuesta" class="zona-apuesta"></div>`;
  const host = $('#apuesta', el), cuenta = $('#cuenta', el), ops = $('#ops', el), acc = $('#acc', el), info = $('#cinfo', el), barra = $('#barra', el);
  const marcar = n => $$('#esc li', el).forEach(li => { const k = +li.dataset.n; li.classList.toggle('actual', k === n); li.classList.toggle('hecho', k < n); });

  function montar(resultado) {
    clearInterval(timer); marcar(0); cuenta.textContent = '?'; ops.innerHTML = ''; acc.innerHTML = ''; barra.style.width = '100%';
    info.textContent = `Elegí tu apuesta y empezá. Tenés ${SEGUNDOS} segundos por cuenta.`;
    panelApuesta(host, ctx, 'cuentas', {boton: 'Empezar', resultado,
      pago: b => b >= 100 ? `${ctx.fmt(Math.floor(b * 0.3))} a ${ctx.fmt(b * 8)}` : '—', onGo: jugar});
  }
  async function jugar(bet) {
    let ronda;
    try { ronda = await ctx.iniciar('cuentas', bet); } catch (e) { ctx.toast(e.message); montar(); return; }
    if (!vivo) return;
    const premio = n => Math.floor(bet * MULT_CUENTAS[n - 1]);
    const cerrar = async pago => {
      clearInterval(timer);
      try { await ctx.cerrar(ronda, pago); } catch (e) { ctx.toast(e.message); }
      return pago;
    };
    const perder = async motivo => {
      acc.innerHTML = ''; ops.querySelectorAll('button').forEach(b => b.disabled = true);
      await cerrar(0); if (!vivo) return;
      info.textContent = motivo;
      setTimeout(() => vivo && montar(clasif(bet, 0, ctx.fmt)), 1400);
    };
    const nivel = n => {
      const q = generarCuenta(n);
      marcar(n); acc.innerHTML = '';
      info.innerHTML = `Nivel <b>${n}</b> de 10 · si te retirás ahora cobrás <b>${ctx.fmt(premio(n))}</b> (x${MULT_CUENTAS[n - 1]}) <small>(solo si respondés bien)</small>`;
      cuenta.textContent = q.txt + ' = ?';
      ops.innerHTML = q.opciones.map(o => `<button class="op" data-v="${o}">${o}</button>`).join('');
      const fin = Date.now() + SEGUNDOS * 1000; let respondida = false;
      barra.style.width = '100%';
      clearInterval(timer);
      timer = setInterval(() => {
        const rest = fin - Date.now();
        barra.style.width = Math.max(0, rest / (SEGUNDOS * 10)) + '%';
        barra.classList.toggle('urge', rest < 2500);
        if (rest <= 0 && !respondida) { respondida = true; clearInterval(timer); perder(`¡Se acabó el tiempo! La respuesta era ${q.res}. Perdiste todo.`); }
      }, 50);
      ops.onclick = async e => {
        const b = e.target.closest('.op'); if (!b || respondida) return;
        respondida = true; clearInterval(timer);
        ops.querySelectorAll('button').forEach(x => x.disabled = true);
        if (+b.dataset.v !== q.res) {
          b.classList.add('mal'); $$('.op', ops).find(x => +x.dataset.v === q.res).classList.add('bien');
          return perder(`Incorrecto: era ${q.res}. Perdiste todo.`);
        }
        b.classList.add('bien');
        if (n === 10) {
          await cerrar(premio(10)); if (!vivo) return;
          info.textContent = '¡Nivel 10 superado! Cobrás x8.';
          return setTimeout(() => vivo && montar(clasif(bet, premio(10), ctx.fmt)), 1100);
        }
        info.innerHTML = `¡Correcto! Podés retirarte con <b>${ctx.fmt(premio(n))}</b> o seguir al nivel ${n + 1} (paga x${MULT_CUENTAS[n]}). Si fallás, perdés todo.`;
        acc.innerHTML = `<button class="btn" id="cobrar">Retirarme y cobrar ${ctx.fmt(premio(n))}</button><button class="btn ghost" id="seguir">Seguir al nivel ${n + 1}</button>`;
        $('#cobrar', el).onclick = async () => {
          acc.querySelectorAll('button').forEach(x => x.disabled = true);
          await cerrar(premio(n)); if (!vivo) return; montar(clasif(bet, premio(n), ctx.fmt));
        };
        $('#seguir', el).onclick = () => nivel(n + 1);
      };
    };
    nivel(1);
  }
  montar();
  return () => { vivo = false; clearInterval(timer); };
}

/* =====================================================================
   CASINO 3: POLLO CRUZANDO LA AVENIDA  (15 niveles, decidís cuándo frenar)
   ===================================================================== */
const POLLO_NIVELES = 15;
const POLLO_P = Array.from({length: POLLO_NIVELES}, (_, i) => +(0.92 - 0.0214 * i).toFixed(4)); // prob. de sobrevivir
const POLLO_MULT = (() => { let prod = 1; return POLLO_P.map(p => { prod *= p; return Math.floor(0.96 / prod * 100) / 100; }); })();

function pollo(el, ctx) {
  let vivo = true, ocupado = false;
  const LANE = 50, CURB = 26, ZONA = 46;
  // De arriba hacia abajo: META, calle 15, vereda 14, ..., vereda 1, calle 1, INICIO
  let html = `<div class="zona-v meta" style="height:${ZONA}px" data-stop="${POLLO_NIVELES}">🏁 META · x${POLLO_MULT[POLLO_NIVELES - 1]}</div>`;
  for (let k = POLLO_NIVELES; k >= 1; k--) {
    const dir = k % 2 ? 'R' : 'L';
    const camiones = [0, 1].map(j => `<span class="camion ${dir}" style="--d:${rango(35, 70) / 10}s;--dl:-${rango(0, 60) / 10}s">${['🛻', '🚚', '🛻'][rnd(3)]}</span>`).join('');
    html += `<div class="carril" data-k="${k}"><em>x${POLLO_MULT[k - 1]}</em>${camiones}</div>`;
    if (k > 1) html += `<div class="vereda" style="height:${CURB}px" data-stop="${k - 1}"></div>`;
  }
  html += `<div class="zona-v inicio" style="height:${ZONA}px" data-stop="0">Vereda de salida</div>`;
  el.innerHTML = `<div class="pollo-wrap">
    <div class="pinfo"><span>Nivel <b id="pn">0</b>/${POLLO_NIVELES}</span><span>Multiplicador <b id="pm">x1.00</b></span><span>Cobrás <b id="pc">${ctx.fmt(0)}</b></span></div>
    <div class="calle" id="calle"><div class="calle-in" id="cin">${html}<div class="gallina" id="gal">🐔</div></div></div>
    <div class="mensaje" id="msg">Elegí tu apuesta y ayudá al pollo a cruzar. Cada calle paga más… y es más peligrosa.</div>
    <div class="acciones" id="acc"></div></div><div id="apuesta" class="zona-apuesta"></div>`;
  const host = $('#apuesta', el), msg = $('#msg', el), acc = $('#acc', el), gal = $('#gal', el), calle = $('#calle', el), cin = $('#cin', el);
  const paradas = k => $(`[data-stop="${k}"]`, el);
  const yDe = e => e.offsetTop + e.offsetHeight / 2 - 18;
  const lanes = {}; $$('.carril', el).forEach(c => lanes[+c.dataset.k] = c);

  function ponerGallina(y, anim = true) {
    gal.style.transition = anim ? 'top .38s ease' : 'none'; gal.style.top = y + 'px';
    const v = y - calle.clientHeight / 2 + 20; if (anim) calle.scrollTo({top: v, behavior: 'smooth'}); else calle.scrollTop = v;
  }
  function reset() {
    $$('.carril', el).forEach(c => c.classList.remove('libre', 'cruzado'));
    $$('.camion.golpe', el).forEach(c => c.remove());
    gal.textContent = '🐔'; gal.classList.remove('muerta');
    ponerGallina(yDe(paradas(0)), false); calle.scrollTop = calle.scrollHeight;
  }
  function montar(resultado) {
    acc.innerHTML = ''; $('#pn', el).textContent = 0; $('#pm', el).textContent = 'x1.00'; $('#pc', el).textContent = ctx.fmt(0);
    reset();
    panelApuesta(host, ctx, 'pollo', {boton: 'Empezar a cruzar', resultado,
      pago: b => b >= 100 ? `hasta ${ctx.fmt(Math.floor(b * POLLO_MULT[POLLO_NIVELES - 1]))}` : '—', onGo: jugar});
  }
  async function jugar(bet) {
    let ronda;
    try { ronda = await ctx.iniciar('pollo', bet); } catch (e) { ctx.toast(e.message); montar(); return; }
    if (!vivo) return;
    let nivel = 0;
    const premio = n => n === 0 ? 0 : Math.floor(bet * POLLO_MULT[n - 1]);
    const marcador = () => { $('#pn', el).textContent = nivel; $('#pm', el).textContent = 'x' + (nivel ? POLLO_MULT[nivel - 1] : 1).toFixed(2); $('#pc', el).textContent = ctx.fmt(premio(nivel)); };
    const botones = () => {
      acc.innerHTML = `<button class="btn" id="avanzar">Avanzar a la calle ${nivel + 1} (x${POLLO_MULT[nivel].toFixed(2)})</button>
        <button class="btn ghost" id="retirar" ${nivel === 0 ? 'disabled' : ''}>Retirarme y cobrar ${ctx.fmt(premio(nivel))}</button>`;
      $('#avanzar', el).onclick = avanzar; $('#retirar', el).onclick = retirar;
    };
    const cerrar = async pago => { try { await ctx.cerrar(ronda, pago); } catch (e) { ctx.toast(e.message); } };
    async function retirar() {
      if (ocupado) return; ocupado = true; acc.innerHTML = '';
      await cerrar(premio(nivel)); ocupado = false; if (!vivo) return;
      montar(clasif(bet, premio(nivel), ctx.fmt));
    }
    async function avanzar() {
      if (ocupado) return; ocupado = true; acc.querySelectorAll('button').forEach(b => b.disabled = true);
      const k = nivel + 1, carril = lanes[k];
      const sobrevive = rfloat() < POLLO_P[k - 1];           // el destino se decide acá, al azar
      msg.textContent = `Cruzando la calle ${k}…`;
      ponerGallina(yDe(carril)); await sleep(400); if (!vivo) return;
      if (sobrevive) {
        carril.classList.add('libre', 'cruzado');
        ponerGallina(yDe(paradas(k))); await sleep(420); if (!vivo) return;
        nivel = k; marcador(); ocupado = false;
        if (nivel === POLLO_NIVELES) { msg.textContent = '¡Llegó a la meta!'; await cerrar(premio(nivel)); if (!vivo) return; return montar(clasif(bet, premio(nivel), ctx.fmt)); }
        msg.textContent = `¡Cruzó la calle ${k}! ¿Seguís o cobrás ${ctx.fmt(premio(nivel))}?`;
        botones();
      } else {
        carril.classList.add('libre');                       // sin camiones decorativos: viene el que lo pisa
        const c = document.createElement('span'); c.className = 'camion golpe L'; c.textContent = '🛻'; carril.append(c);
        c.animate([{left: '100%'}, {left: '-90px'}], {duration: 850, easing: 'linear'});
        await sleep(400); if (!vivo) return;
        gal.textContent = '💥'; gal.classList.add('muerta'); msg.textContent = `¡Una camioneta pisó al pollo en la calle ${k}!`;
        await sleep(850); if (!vivo) return;
        await cerrar(0); ocupado = false; if (!vivo) return;
        montar(clasif(bet, 0, ctx.fmt));
      }
    }
    msg.textContent = 'Listo para cruzar. Tocá “Avanzar”.'; marcador(); botones();
  }
  montar();
  setTimeout(() => { if (vivo) { ponerGallina(yDe(paradas(0)), false); calle.scrollTop = calle.scrollHeight; } }, 50);
  return () => { vivo = false; };
}

/* =====================================================================
   ARCADE 1: MEMORIA DE PARES  (5 intentos fallidos, gana x2)
   ===================================================================== */
const SIMBOLOS = ['🍒', '🍋', '🔔', '⭐', '💎', '🍀', '🎲', '🃏', '👑', '🎰', '🍉', '🔥', '🚀', '🦄'];
const PARES = 6, INTENTOS = 5;
function memoria(el, ctx) {
  let vivo = true;
  el.innerHTML = `<div class="memoria">
    <div class="minfo"><span>Pares encontrados <b id="mp">0</b>/${PARES}</span><span>Intentos fallidos <b id="mf">0</b>/${INTENTOS}</span><span class="vidas" id="vidas"></span></div>
    <div class="mgrid" id="mg"></div>
    <div class="mensaje" id="msg">Elegí tu apuesta. Encontrá los ${PARES} pares antes de fallar ${INTENTOS} veces.</div></div>
    <div id="apuesta" class="zona-apuesta"></div>`;
  const host = $('#apuesta', el), mg = $('#mg', el), msg = $('#msg', el);
  const vidas = f => $('#vidas', el).innerHTML = Array.from({length: INTENTOS}, (_, i) => `<i class="${i < f ? 'x' : ''}"></i>`).join('');
  function tablero(juego) {   // cartas dadas vuelta (decorativas) hasta que se empieza
    mg.innerHTML = Array.from({length: PARES * 2}, () => `<div class="mcarta"><div class="mcara"></div><div class="mdorso">?</div></div>`).join('');
    mg.classList.toggle('inactivo', !juego);
  }
  function montar(resultado) {
    tablero(false); vidas(0); $('#mp', el).textContent = 0; $('#mf', el).textContent = 0;
    panelApuesta(host, ctx, 'memoria', {boton: 'Repartir cartas', resultado, pago: b => b >= 100 ? ctx.fmt(b * 2) : '—', onGo: jugar});
  }
  async function jugar(bet) {
    let ronda;
    try { ronda = await ctx.iniciar('memoria', bet); } catch (e) { ctx.toast(e.message); montar(); return; }
    if (!vivo) return;
    // Cada partida: otros símbolos y otras posiciones (todo al azar)
    const mazo = shuffle(shuffle(SIMBOLOS).slice(0, PARES).flatMap(s => [s, s]));
    mg.classList.remove('inactivo');
    mg.innerHTML = mazo.map((s, i) => `<button class="mcarta" data-i="${i}" aria-label="Carta ${i + 1}"><span class="mcara">${s}</span><span class="mdorso">?</span></button>`).join('');
    const cartas = $$('.mcarta', mg);
    let abiertas = [], fallos = 0, pares = 0, bloqueo = false, fin = false;
    msg.textContent = `Apuesta en juego: ${ctx.fmt(bet)}. Tocá dos cartas para buscar el par.`;
    const cerrar = async (pago, titulo) => {
      fin = true; bloqueo = true;
      cartas.forEach(c => c.classList.add('abierta'));
      try { await ctx.cerrar(ronda, pago); } catch (e) { ctx.toast(e.message); }
      if (!vivo) return; msg.textContent = titulo;
      setTimeout(() => vivo && montar(clasif(bet, pago, ctx.fmt)), 1800);
    };
    mg.onclick = async e => {
      const c = e.target.closest('.mcarta'); if (!c || bloqueo || fin || c.classList.contains('abierta')) return;
      c.classList.add('abierta'); abiertas.push(c);
      if (abiertas.length < 2) return;
      bloqueo = true;
      const [a, b] = abiertas; abiertas = [];
      if (mazo[+a.dataset.i] === mazo[+b.dataset.i]) {
        a.classList.add('par'); b.classList.add('par'); pares++; $('#mp', el).textContent = pares;
        if (pares === PARES) return cerrar(bet * 2, '¡Encontraste todos los pares! Cobrás x2.');
        msg.textContent = '¡Par! Seguí así.'; bloqueo = false;
      } else {
        fallos++; $('#mf', el).textContent = fallos; vidas(fallos);
        msg.textContent = `No coinciden. Intento fallido ${fallos} de ${INTENTOS}.`;
        await sleep(950); if (!vivo) return;
        if (fallos >= INTENTOS) return cerrar(0, `Llegaste a ${INTENTOS} intentos fallidos. Perdiste tu apuesta.`);
        a.classList.remove('abierta'); b.classList.remove('abierta'); bloqueo = false;
      }
    };
  }
  montar();
  return () => { vivo = false; };
}

/* =====================================================================
   ARCADE 2: MINA SEGURA  (5x5, 3 minas, retirás cuando quieras)
   ===================================================================== */
const MINAS = 3, CASILLAS = 25, TOPE_MINAS = 100;
const multMinas = k => { let m = 0.96; for (let i = 0; i < k; i++) m *= (CASILLAS - i) / (CASILLAS - MINAS - i); return Math.min(TOPE_MINAS, Math.floor(m * 100) / 100); };
function minas(el, ctx) {
  let vivo = true;
  el.innerHTML = `<div class="minas">
    <div class="pinfo"><span>Casillas seguras <b id="ms">0</b>/${CASILLAS - MINAS}</span><span>Multiplicador <b id="mm">x1.00</b></span><span>Cobrás <b id="mc">${ctx.fmt(0)}</b></span></div>
    <div class="mgrid5" id="g"></div>
    <div class="mensaje" id="msg">Hay ${MINAS} minas escondidas entre 25 casillas. Cada casilla segura multiplica tu apuesta.</div>
    <div class="acciones" id="acc"></div></div><div id="apuesta" class="zona-apuesta"></div>`;
  const host = $('#apuesta', el), g = $('#g', el), msg = $('#msg', el), acc = $('#acc', el);
  function montar(resultado) {
    acc.innerHTML = ''; $('#ms', el).textContent = 0; $('#mm', el).textContent = 'x1.00'; $('#mc', el).textContent = ctx.fmt(0);
    g.classList.add('inactivo');
    g.innerHTML = Array.from({length: CASILLAS}, () => `<button class="casilla" disabled>?</button>`).join('');
    panelApuesta(host, ctx, 'minas', {boton: 'Empezar', resultado, pago: b => b >= 100 ? `hasta ${ctx.fmt(Math.floor(b * multMinas(CASILLAS - MINAS)))}` : '—', onGo: jugar});
  }
  async function jugar(bet) {
    let ronda;
    try { ronda = await ctx.iniciar('minas', bet); } catch (e) { ctx.toast(e.message); montar(); return; }
    if (!vivo) return;
    const hay = new Set(shuffle([...Array(CASILLAS).keys()]).slice(0, MINAS));
    let seguras = 0, fin = false;
    g.classList.remove('inactivo');
    g.innerHTML = Array.from({length: CASILLAS}, (_, i) => `<button class="casilla" data-i="${i}" aria-label="Casilla ${i + 1}">?</button>`).join('');
    const premio = () => Math.floor(bet * multMinas(seguras));
    const marcador = () => { $('#ms', el).textContent = seguras; $('#mm', el).textContent = 'x' + multMinas(seguras).toFixed(2); $('#mc', el).textContent = ctx.fmt(seguras ? premio() : 0); };
    const mostrarTodo = () => $$('.casilla', g).forEach(c => { const i = +c.dataset.i; c.disabled = true; if (hay.has(i)) { c.textContent = '💣'; c.classList.add('mina'); } else if (!c.classList.contains('segura')) { c.textContent = '💎'; c.classList.add('oculta-segura'); } });
    const cerrar = async (pago, titulo) => {
      fin = true; acc.innerHTML = ''; mostrarTodo();
      try { await ctx.cerrar(ronda, pago); } catch (e) { ctx.toast(e.message); }
      if (!vivo) return; msg.textContent = titulo;
      setTimeout(() => vivo && montar(clasif(bet, pago, ctx.fmt)), 1700);
    };
    const botonCobrar = () => {
      acc.innerHTML = `<button class="btn" id="cobrar" ${seguras ? '' : 'disabled'}>Retirarme y cobrar ${ctx.fmt(premio())}</button>`;
      $('#cobrar', el).onclick = () => !fin && cerrar(premio(), `Te retiraste con ${ctx.fmt(premio())}.`);
    };
    msg.textContent = `Apuesta en juego: ${ctx.fmt(bet)}. Descubrí casillas sin pisar una mina.`; botonCobrar();
    g.onclick = e => {
      const c = e.target.closest('.casilla'); if (!c || fin || c.disabled) return;
      const i = +c.dataset.i; c.disabled = true;
      if (hay.has(i)) { c.textContent = '💣'; c.classList.add('mina', 'boom'); return cerrar(0, '¡Pisaste una mina! Perdiste tu apuesta.'); }
      c.textContent = '💎'; c.classList.add('segura'); seguras++; marcador();
      if (multMinas(seguras) >= TOPE_MINAS || seguras === CASILLAS - MINAS) return cerrar(premio(), '¡Llegaste al máximo! Cobrás todo.');
      msg.textContent = `¡Segura! Próxima casilla: x${multMinas(seguras + 1).toFixed(2)}.`; botonCobrar();
    };
  }
  montar();
  return () => { vivo = false; };
}

/* =====================================================================
   ARCADE 3: CRASH ROCKET  (retirá antes de que el cohete explote)
   ===================================================================== */
const historialCrash = [];
function crash(el, ctx) {
  let vivo = true, raf = 0;
  el.innerHTML = `<div class="crash">
    <div class="chist" id="ch"></div>
    <div class="cvwrap"><canvas id="cv"></canvas><div class="cmult" id="cm">x1.00</div></div>
    <div class="mensaje" id="msg">Elegí tu apuesta y despegá. El cohete sube… y en algún momento explota.</div>
    <div class="acciones" id="acc"></div></div><div id="apuesta" class="zona-apuesta"></div>`;
  const host = $('#apuesta', el), cv = $('#cv', el), cm = $('#cm', el), msg = $('#msg', el), acc = $('#acc', el), ctx2 = cv.getContext('2d');
  const hist = () => $('#ch', el).innerHTML = historialCrash.slice(-10).map(v => `<span class="${v >= 2 ? 'alto' : 'bajo'}">x${v.toFixed(2)}</span>`).join('') || '<span class="vacio">Sin rondas todavía</span>';
  function medir() { const r = cv.getBoundingClientRect(), d = window.devicePixelRatio || 1; cv.width = r.width * d; cv.height = r.height * d; ctx2.setTransform(d, 0, 0, d, 0, 0); return {w: r.width, h: r.height}; }
  function dibujar(t, m, estado) {
    const {w, h} = medir();
    ctx2.clearRect(0, 0, w, h);
    const xmax = Math.max(8, t * 1.15), ymax = Math.max(2, m * 1.25), pad = 28;
    const X = tt => pad + (tt / xmax) * (w - pad * 1.6), Y = mm => h - pad - ((mm - 1) / (ymax - 1)) * (h - pad * 1.8);
    ctx2.strokeStyle = 'rgba(230,195,106,.15)'; ctx2.lineWidth = 1; ctx2.fillStyle = 'rgba(230,195,106,.55)'; ctx2.font = '11px Manrope, sans-serif';
    for (let i = 0; i <= 4; i++) { const mm = 1 + (ymax - 1) * i / 4, y = Y(mm); ctx2.beginPath(); ctx2.moveTo(pad, y); ctx2.lineTo(w - 6, y); ctx2.stroke(); ctx2.fillText('x' + mm.toFixed(1), 2, y - 3); }
    ctx2.beginPath(); const pasos = 80;
    for (let i = 0; i <= pasos; i++) { const tt = t * i / pasos, mm = Math.exp(0.12 * tt); const x = X(tt), y = Y(mm); i ? ctx2.lineTo(x, y) : ctx2.moveTo(x, y); }
    ctx2.strokeStyle = estado === 'boom' ? '#ff5a64' : '#e6c36a'; ctx2.lineWidth = 3; ctx2.stroke();
    ctx2.font = '28px serif'; ctx2.fillText(estado === 'boom' ? '💥' : '🚀', X(t) - 12, Y(m) + 6);
  }
  function montar(resultado) {
    cancelAnimationFrame(raf); acc.innerHTML = ''; cm.textContent = 'x1.00'; cm.className = 'cmult'; hist(); dibujar(0, 1);
    panelApuesta(host, ctx, 'crash', {boton: 'Despegar', resultado, pago: b => b >= 100 ? `apuesta × multiplicador` : '—', onGo: jugar});
  }
  async function jugar(bet) {
    let ronda;
    try { ronda = await ctx.iniciar('crash', bet); } catch (e) { ctx.toast(e.message); montar(); return; }
    if (!vivo) return;
    // Punto de explosión: probabilidad de llegar a x es 96/x (4% de ventaja de la casa)
    const cp = Math.min(100, Math.max(1, Math.floor(0.96 / (1 - rfloat()) * 100) / 100));
    let t = 0, last = performance.now(), cobrado = null, escala = 1, termino = false;
    msg.textContent = `Apuesta en juego: ${ctx.fmt(bet)}. ¡Retirate antes de que explote!`;
    acc.innerHTML = `<button class="btn" id="cobrar">Retirar ahora</button>`;
    const btn = $('#cobrar', el);
    const mult = () => Math.floor(Math.exp(0.12 * t) * 100) / 100;
    const cobrar = async m => {
      if (cobrado !== null || termino) return;
      const pago = Math.floor(bet * m); cobrado = {m, pago}; btn.disabled = true; escala = 4;
      msg.textContent = `¡Te retiraste en x${m.toFixed(2)}! Cobrás ${ctx.fmt(pago)}. Veamos hasta dónde llegaba…`;
      try { await ctx.cerrar(ronda, pago); } catch (e) { ctx.toast(e.message); }
    };
    btn.onclick = () => { if (!termino) cobrar(Math.max(1, Math.min(mult(), cp))); };
    const frame = async now => {
      if (!vivo) return;
      t += Math.min(0.1, (now - last) / 1000) * escala; last = now;
      const m = mult();
      if (m >= cp) {                          // explotó (o llegó al tope de x100)
        termino = true; const tope = cp >= 100;
        if (tope && cobrado === null) await cobrar(100);
        cm.textContent = 'x' + cp.toFixed(2); cm.className = 'cmult ' + (tope ? '' : 'boom');
        dibujar(Math.log(cp) / 0.12, cp, tope ? 'ok' : 'boom');
        historialCrash.push(cp); hist(); btn.disabled = true;
        if (cobrado === null) { try { await ctx.cerrar(ronda, 0); } catch (e) { ctx.toast(e.message); } }
        if (!vivo) return;
        msg.textContent = tope ? 'El cohete llegó al máximo (x100).' : `¡El cohete explotó en x${cp.toFixed(2)}!`;
        const pago = cobrado ? cobrado.pago : 0;
        setTimeout(() => vivo && montar(clasif(bet, pago, ctx.fmt)), 1500);
        return;
      }
      cm.textContent = 'x' + m.toFixed(2); dibujar(t, Math.exp(0.12 * t));
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);
  }
  montar();
  const onResize = () => { if (!raf) dibujar(0, 1); };
  window.addEventListener('resize', onResize);
  return () => { vivo = false; cancelAnimationFrame(raf); window.removeEventListener('resize', onResize); };
}

/* ---------- Catálogo: 3 juegos de casino + 3 de arcade ---------- */
window.PopiJuegos = {
  casino: [
    {id: 'blackjack', n: 'Blackjack', c: 'Cartas', icon: '🃏', h: 150, desc: 'Llegá a 21 sin pasarte. La casa reparte de a una carta y su segunda carta queda tapada hasta que te plantás.',
      reglas: ['Si ganás cobrás x2 (apostás 10.000, tenés 20.000)', 'Empate: recuperás tu apuesta', 'La casa pide hasta llegar a 17'], mount: blackjack},
    {id: 'cuentas', n: 'Cuentas rápidas', c: 'Matemática', icon: '🧮', h: 210, desc: '10 niveles de cuentas, de fácil a difícil. 7 segundos por cuenta y 5 opciones. Vos decidís cuándo retirarte.',
      reglas: ['Nivel 1 paga x0,30 y el nivel 10 paga x8', 'Si te equivocás o se acaba el tiempo, perdés todo', 'Retirate después de cada acierto'], mount: cuentas},
    {id: 'pollo', n: 'Pollo en la avenida', c: 'Riesgo', icon: '🐔', h: 45, desc: 'Ayudá al pollo a cruzar 15 calles llenas de camionetas. Cada calle paga más, pero si te pisan perdés.',
      reglas: ['15 niveles, cada uno con más multiplicador', 'Todo es al azar: no hay calle “segura”', 'Retirate cuando quieras para cobrar'], mount: pollo}
  ],
  arcade: [
    {id: 'memoria', n: 'Memoria de pares', c: 'Memoria', icon: '🧠', h: 280, desc: 'Dá vuelta las cartas y encontrá los 6 pares. Tenés 5 intentos fallidos: al quinto, perdés.',
      reglas: ['Si encontrás todos los pares cobrás x2', 'Cada partida mezcla cartas y posiciones', '5 intentos fallidos y perdés la apuesta'], mount: memoria},
    {id: 'minas', n: 'Mina segura', c: 'Estrategia', icon: '💣', h: 330, desc: 'Descubrí casillas sin pisar una de las 3 minas. Cada casilla segura multiplica tu apuesta.',
      reglas: ['Tablero de 5x5 con 3 minas al azar', 'Retirate cuando quieras', 'Multiplicador máximo x100'], mount: minas},
    {id: 'crash', n: 'Crash Rocket', c: 'Reflejos', icon: '🚀', h: 12, desc: 'El cohete sube multiplicando tu apuesta. Retirate antes de que explote.',
      reglas: ['El punto de explosión es aleatorio', 'Si no te retirás a tiempo, perdés', 'Multiplicador máximo x100'], mount: crash}
  ]
};
})();
