/* Popicasino: programa principal (sesión, saldo, menús y vistas).
   Todo lo importante (usuarios, contraseñas encriptadas, saldo, apuestas, depósitos y retiros)
   vive en la base de datos MySQL y se maneja desde los archivos PHP de la carpeta /api. */
(() => {
'use strict';
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt = n => new Intl.NumberFormat('es-AR', {style:'currency', currency:'ARS', maximumFractionDigits:0}).format(n);
const rd = (k, d) => { try { const v = JSON.parse(localStorage.getItem(k)); return v ?? d; } catch (e) { return d; } };
const wr = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} };
const fechaHora = s => { const d = new Date(String(s).replace(' ', 'T')); return isNaN(d) ? '' : d.toLocaleString('es-AR', {day:'2-digit', month:'2-digit', year:'numeric', hour:'2-digit', minute:'2-digit'}); };

/* ---------- Comunicación con el servidor (PHP) ---------- */
async function api(endpoint, cuerpo) {
  try {
    const r = await fetch('api/' + endpoint + '.php', {method: 'POST', credentials: 'same-origin',
      headers: {'Content-Type': 'application/json'}, body: JSON.stringify(cuerpo || {})});
    let j; try { j = await r.json(); } catch (e) { j = {ok: false, error: 'El servidor no respondió bien. ¿Están prendidos Apache y MySQL en XAMPP?', red: true}; }
    return j;
  } catch (e) {
    return {ok: false, red: true, error: 'No se pudo conectar con el servidor. Abrí el sitio desde http://localhost/ (con XAMPP prendido) y no haciendo doble clic en el archivo.'};
  }
}

const page = document.body.dataset.page;

window.Popi = {
  registrar: d => api('registro', d),
  entrar: (mail, pass) => api('login', {mail, pass}),
  async salir() { await api('logout'); location.href = 'Popicasino.html'; },
  api, fmt, esc
};
if (!page) return;
if (page === 'login') { api('sesion').then(r => { if (r.ok) location.replace('inicio.html'); }); return; }

let user = null;

/* ---------- Catálogo: slots (sin juegos todavía) ---------- */
const g = (n, c, desc, min, max, info, h) => ({n, c, desc, min, max, info, h});
const SLOTS = {titulo:'Slots', desc:'Tragamonedas con rodillos, bonus y jackpots.', filtros:['Todos','Clásicas','Video slots','Jackpot'], items:[
  g('Gallo de Oro','Clásicas','Cinco rodillos, símbolos de campo y giros gratis.',50,5000,[['Retorno (RTP)','96,2%'],['Volatilidad','Media'],['Rodillos','5 x 3'],['Premio máximo','x5.000']],42),
  g('Pampa Fortune','Video slots','Bonus de caballos con multiplicadores crecientes.',50,5000,[['Retorno (RTP)','95,8%'],['Volatilidad','Alta'],['Rodillos','5 x 4'],['Premio máximo','x10.000']],95),
  g('Tango Reels','Clásicas','Tres rodillos con símbolos de la vieja confitería.',20,2000,[['Retorno (RTP)','96,5%'],['Volatilidad','Baja'],['Rodillos','3 x 3'],['Premio máximo','x800']],8),
  g('Mega Popi','Jackpot','Jackpot progresivo compartido entre todos los jugadores.',100,10000,[['Retorno (RTP)','94,9%'],['Volatilidad','Alta'],['Jackpot actual',fmt(8450000)],['Premio máximo','Jackpot']],350),
  g('Sierra Gold','Video slots','Minas, vagonetas y cascadas de símbolos.',50,5000,[['Retorno (RTP)','96,0%'],['Volatilidad','Media'],['Rodillos','6 x 5'],['Premio máximo','x6.500']],28),
  g('Cóndor Real','Jackpot','Cuatro jackpots fijos que se activan al azar.',100,8000,[['Retorno (RTP)','95,1%'],['Volatilidad','Alta'],['Jackpots','4 niveles'],['Premio máximo','x25.000']],200)]};

const POSTS0 = [
  {u:'Marcos P.', t:'hace 2 h', txt:'Argentina gana + Real Madrid gana', q:1.96, m:500, likes:14},
  {u:'Lucía R.', t:'hace 5 h', txt:'Boca Juniors gana la final de la Sudamericana', q:2.9, m:1000, likes:6},
  {u:'Nico D.', t:'ayer', txt:'Más de 2,5 goles en España vs Inglaterra', q:1.95, m:2000, likes:22}
];

/* ---------- Estructura común ---------- */
const NAV = [['inicio','Inicio'],['deportes','Apuestas deportivas'],['slots','Slots'],['arcade','Arcade'],['casino','Casino'],['social','Social'],['cuenta','Mi cuenta']];

function toast(m) { const t = document.createElement('div'); t.className = 'toast'; t.textContent = m; document.body.append(t); setTimeout(() => t.remove(), 2600); }
function modal(html) {
  const m = document.createElement('div'); m.className = 'modal'; m.setAttribute('role', 'dialog'); m.setAttribute('aria-modal', 'true');
  m.innerHTML = `<div class="mbox">${html}</div>`;
  const cerrar = () => { m.remove(); document.removeEventListener('keydown', esc2); };
  const esc2 = e => e.key === 'Escape' && cerrar();
  m.addEventListener('click', e => { if (e.target === m || e.target.closest('[data-x]')) cerrar(); });
  document.addEventListener('keydown', esc2); document.body.append(m);
  const f = $('input,button:not([data-x])', m); if (f) f.focus();
  return {el: m, cerrar};
}
function shell() {
  document.body.innerHTML = `<div class="app">
  <nav class="side" aria-label="Principal"><a class="brand" href="inicio.html">Popicasino</a>
    ${NAV.map(([id, n]) => `<a class="nav" href="${id}.html" ${id === page ? 'aria-current="page"' : ''}>${n}</a>`).join('')}
    <span class="sp"></span></nav>
  <div><div class="top"><a class="brand" href="inicio.html">Popicasino</a>
    <span class="who">${esc(user.nombre)} ${esc(user.apellido)}</span>
    <div class="saldo"><small>Saldo</small><b id="saldo">${fmt(user.saldo)}</b></div>
    <button class="btn sm" id="dep">Depositar</button></div>
    <main class="main" id="app"></main></div></div>`;
  $('#dep').onclick = () => cajero('Depositar');
}
function setSaldo(n) { user.saldo = n; const s = $('#saldo'); if (s) { s.textContent = fmt(n); s.classList.remove('pulso'); void s.offsetWidth; s.classList.add('pulso'); } }

/* ---------- Depositar / retirar (SIMULADO, guardado en la base de datos) ---------- */
const METODOS = [['transferencia','Transferencia bancaria','Desde tu CBU/CVU'], ['billetera','Billetera virtual','Mercado Pago, Ualá, etc.'], ['tarjeta','Tarjeta','Débito o crédito']];
const NOM_METODO = {transferencia:'Transferencia bancaria', billetera:'Billetera virtual', tarjeta:'Tarjeta'};
function cajero(tipo) {
  const dep = tipo === 'Depositar', min = dep ? 500 : 1000;
  let metodo = 'transferencia';
  const m = modal(`<div class="mbody" id="cj"><h2>${tipo}</h2>
    <p>${dep ? 'Elegí cómo cargar fichas y cuánto.' : `Disponible para retirar: <b>${fmt(user.saldo)}</b>`}</p>
    <div class="metodos" role="radiogroup" aria-label="Medio de pago">${METODOS.map(([id, n, d]) => `<button type="button" class="metodo" role="radio" data-m="${id}" aria-checked="${id === metodo}"><b>${n}</b><small>${d}</small></button>`).join('')}</div>
    <div class="chips">${(dep ? [1000, 5000, 10000, 20000, 50000] : [1000, 5000, 10000, 20000]).map(v => `<button type="button" class="chip" data-v="${v}">${fmt(v)}</button>`).join('')}</div>
    <input type="number" id="monto" min="${min}" step="100" placeholder="Otro monto (mínimo ${fmt(min)})" aria-label="Monto">
    ${dep ? '' : `<input type="text" id="dest" maxlength="22" placeholder="CBU/CVU (22 números) o alias" aria-label="CBU, CVU o alias" style="margin-top:10px">`}
    <p class="err" id="merr"></p>
    <p class="nota-sim">Simulación escolar: no se mueve dinero real y no se piden datos de tarjetas ni cuentas verdaderas.</p>
    <div class="mact"><button class="btn ghost sm" data-x>Cancelar</button><button class="btn sm" id="ok">${tipo}</button></div></div>`);
  $$('.metodo', m.el).forEach(b => b.onclick = () => { metodo = b.dataset.m; $$('.metodo', m.el).forEach(x => x.setAttribute('aria-checked', x === b)); });
  $$('.chip', m.el).forEach(c => c.onclick = () => $('#monto', m.el).value = c.dataset.v);
  $('#ok', m.el).onclick = async () => {
    const v = Math.floor(+$('#monto', m.el).value), err = $('#merr', m.el);
    const destino = dep ? '' : $('#dest', m.el).value.trim();
    let e = !(v >= min) ? `Ingresá un monto de ${fmt(min)} o más.` : (!dep && v > user.saldo ? 'No tenés saldo suficiente.' : '');
    if (!e && !dep && !/^\d{22}$/.test(destino) && !/^[A-Za-z0-9.\-]{6,20}$/.test(destino)) e = 'Ingresá un CBU/CVU de 22 números o un alias de 6 a 20 caracteres.';
    err.textContent = e; if (e) return;
    const b = $('#ok', m.el); b.disabled = true;
    const r = await api('transaccion', {accion: dep ? 'deposito' : 'retiro', metodo, monto: v, destino});
    if (!r.ok) { err.textContent = r.error || 'No se pudo completar.'; b.disabled = false; return; }
    setSaldo(r.saldo);
    $('#cj', m.el).innerHTML = `<h2>${dep ? 'Depósito acreditado' : 'Retiro solicitado'}</h2>
      <div class="comprobante">
        <div><small>Comprobante</small><b>${esc(r.codigo)}</b></div>
        <div><small>Monto</small><b>${fmt(r.monto)}</b></div>
        <div><small>Medio</small><b>${esc(NOM_METODO[r.metodo] || r.metodo)}</b></div>
        <div><small>Estado</small><b class="est ${esc(r.estado)}">${r.estado === 'procesando' ? 'Procesando (se completa en unos segundos)' : 'Acreditado'}</b></div>
        <div><small>Fecha</small><b>${fechaHora(r.fecha)}</b></div>
        <div><small>Saldo actual</small><b>${fmt(r.saldo)}</b></div>
      </div>
      <div class="mact"><button class="btn sm" data-x>Listo</button></div>`;
    if (page === 'cuenta') vistaCuenta();
  };
}

/* ---------- Contexto que usan los juegos ---------- */
const ctxJuegos = {
  saldo: () => user.saldo, fmt, esc, toast, depositar: () => cajero('Depositar'),
  async iniciar(juego, apuesta) {
    const r = await api('juego', {accion: 'start', juego, apuesta});
    if (!r.ok) { if (r.sesion === false) location.replace('Popicasino.html'); throw new Error(r.error || 'No se pudo iniciar la partida.'); }
    setSaldo(r.saldo); return r.ronda;
  },
  async cerrar(ronda, pago) {
    const r = await api('juego', {accion: 'end', ronda, pago});
    if (!r.ok) throw new Error(r.error || 'No se pudo acreditar el premio.');
    setSaldo(r.saldo); return r.saldo;
  }
};

/* ---------- Vistas ---------- */
const root = () => $('#app');
const cardJuego = (cat, j) => `<a class="game" href="${cat}.html#${j.id}" style="--h:${j.h}"><span class="cover"><i>${esc(j.c)}</i><b class="ico">${j.icon}</b></span><span class="gname">${esc(j.n)}</span><span class="gmeta">Apostá desde ${fmt(100)}</span></a>`;
const card = (i, j) => `<button class="game" data-i="${i}" style="--h:${j.h}"><span class="cover"><i>Próximamente</i><b>${esc(j.n[0])}</b></span><span class="gname">${esc(j.n)}</span><span class="gmeta">Desde ${fmt(j.min)}</span></button>`;

function vistaPrevia(i) {
  const j = SLOTS.items[i];
  modal(`<div class="cover" style="--h:${j.h}"><b>${esc(j.n)}</b></div><div class="mbody"><h2>${esc(j.n)}</h2><p>${esc(j.desc)}</p>
    <div class="info">${j.info.map(([a, b]) => `<div><small>${a}</small>${esc(b)}</div>`).join('')}
      <div><small>Apuesta mínima</small>${fmt(j.min)}</div><div><small>Apuesta máxima</small>${fmt(j.max)}</div></div>
    <div class="mact"><button class="btn ghost sm" data-x>Volver</button><button class="btn sm" disabled>Jugar (próximamente)</button></div></div>`);
}
function lobbySlots() {
  const c = SLOTS;
  root().innerHTML = `<header><h1>${c.titulo}</h1><p class="sub">${c.desc}</p></header>
    <div class="chips">${c.filtros.map((f, k) => `<button class="chip" aria-pressed="${k === 0}">${f}</button>`).join('')}</div>
    <div class="grid" id="grid"></div>`;
  const pintar = f => $('#grid').innerHTML = c.items.map((j, i) => (f === 'Todos' || j.c === f) ? card(i, j) : '').join('');
  pintar('Todos');
  $$('.chip').forEach(b => b.onclick = () => { $$('.chip').forEach(x => x.setAttribute('aria-pressed', x === b)); pintar(b.textContent); });
  root().onclick = e => { const b = e.target.closest('.game'); if (b) vistaPrevia(+b.dataset.i); };
}

/* Casino y Arcade: lobby con las 3 tarjetas, y cada juego en #id */
let limpiarJuego = null;
function vistaJuegos(cat) {
  const lista = window.PopiJuegos[cat], nombre = cat === 'casino' ? 'Casino' : 'Arcade';
  const subt = cat === 'casino' ? 'Tres juegos de mesa y azar. Elegí tus fichas abajo antes de cada partida.' : 'Tres juegos rápidos de habilidad y memoria. Elegí tus fichas antes de empezar.';
  const ruta = () => {
    if (limpiarJuego) { limpiarJuego(); limpiarJuego = null; }
    const j = lista.find(x => x.id === location.hash.slice(1));
    window.scrollTo(0, 0);
    if (!j) {
      root().innerHTML = `<header><h1>${nombre}</h1><p class="sub">${subt}</p></header><div class="grid">${lista.map(x => cardJuego(cat, x)).join('')}</div>`;
    } else {
      root().innerHTML = `<header><a class="volver" href="${cat}.html">← Volver a ${nombre}</a><h1>${esc(j.n)}</h1><p class="sub">${esc(j.desc)}</p>
        <ul class="reglas">${j.reglas.map(r => `<li>${esc(r)}</li>`).join('')}</ul></header><div id="juego" class="juego"></div>`;
      limpiarJuego = j.mount($('#juego'), ctxJuegos);
    }
    const pie = document.createElement('footer'); pie.className = 'foot'; pie.textContent = TEXTO_PIE; root().append(pie);
  };
  window.addEventListener('hashchange', ruta); ruta();
}

/* Apuestas deportivas (fútbol) */
const boleto = [];
function vistaDeportes() {
  const COMP = window.COMPETENCIAS, PART = window.PARTIDOS;
  const hoyISO = (() => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; })();
  const filtros = [['todos', 'Todos'], ['hoy', 'Hoy'], ...COMP.map(c => [c.id, c.n])];
  root().innerHTML = `<header><h1>Apuestas deportivas · Fútbol</h1><p class="sub">Partidos desde el 12/11/2026 (horario de Argentina). Elegí una cuota, armá tu boleto y apostá. Cuotas de referencia: modelo escolar, sin dinero real.</p></header>
    <div class="chips" id="filtros">${filtros.map(([id, n], k) => `<button class="chip" data-f="${id}" aria-pressed="${k === 0}">${esc(n)}</button>`).join('')}</div>
    <div class="dep"><div id="evs"></div><aside class="panel boleto" id="bol"></aside></div>`;
  let filtro = 'todos';
  const fechaTxt = f => { const d = new Date(f + 'T12:00:00'); const t = d.toLocaleDateString('es-AR', {weekday: 'short', day: 'numeric', month: 'numeric'}); return (f === hoyISO ? 'Hoy · ' : '') + t.charAt(0).toUpperCase() + t.slice(1); };
  const sel = (i, mk) => boleto.some(b => b.i === i && b.mk === mk);
  const boton = (i, mk, lab, q) => `<button class="odd" data-i="${i}" data-mk="${mk}" aria-pressed="${sel(i, mk)}"><span>${esc(lab)}</span><b>${q.toFixed(2)}</b></button>`;
  const pintar = () => {
    let html = '';
    for (const c of COMP) {
      const lista = PART.map((p, i) => ({p, i})).filter(({p}) => p.comp === c.id && (filtro === 'todos' || filtro === c.id || (filtro === 'hoy' && p.fecha === hoyISO)))
        .sort((a, b) => (a.p.fecha + (a.p.hora || '99:99')).localeCompare(b.p.fecha + (b.p.hora || '99:99')));
      if (!lista.length) continue;
      html += `<section class="comp"><h2>${esc(c.n)}</h2><p class="sub">${esc(c.sub)}</p>` + lista.map(({p, i}) => `
        <div class="ev"><div><small>${fechaTxt(p.fecha)}${p.hora ? ' · ' + p.hora + ' h' : ''}${p.sede ? ' · ' + esc(p.sede) : ''}</small><strong>${esc(p.l)} vs ${esc(p.v)}</strong></div>
          <div class="odds">${boton(i, '1', p.l, p.q[0])}${boton(i, 'X', 'Empate', p.q[1])}${boton(i, '2', p.v, p.q[2])}</div>
          <div class="odds ou">${boton(i, 'O', 'Más de 2,5 goles', p.ou[0])}${boton(i, 'U', 'Menos de 2,5 goles', p.ou[1])}</div></div>`).join('') + '</section>';
    }
    $('#evs').innerHTML = html || '<p class="vacio">No hay partidos para este filtro.</p>';
  };
  const pintarBol = () => {
    const q = boleto.reduce((a, b) => a * b.q, 1);
    $('#bol').innerHTML = `<h3>Mi boleto</h3>${boleto.length ? boleto.map(b => `<div class="pick"><span>${esc(b.txt)}</span><b>${b.q.toFixed(2)}</b></div>`).join('') : '<p class="vacio">Tocá una cuota para sumarla.</p>'}
      <div class="row"><span>Cuota total</span><b>${boleto.length ? q.toFixed(2) : '0,00'}</b></div>
      <div class="chips" style="margin:8px 0">${[100, 500, 1000, 5000].map(v => `<button class="chip" data-s="${v}">${fmt(v)}</button>`).join('')}</div>
      <input type="number" id="stake" min="100" step="100" placeholder="Monto (mínimo $100)" aria-label="Monto a apostar">
      <div class="row"><span>Ganancia posible</span><b id="gan">${fmt(0)}</b></div>
      <label class="chk"><input type="checkbox" id="share"><span>Compartir en Social</span></label>
      <p class="err" id="berr"></p><button class="btn full" id="apostar" style="width:100%" ${boleto.length ? '' : 'disabled'}>Apostar</button>`;
    $('#stake').oninput = e => $('#gan').textContent = fmt((+e.target.value || 0) * q);
    $$('[data-s]', $('#bol')).forEach(c => c.onclick = () => { $('#stake').value = c.dataset.s; $('#stake').oninput({target: $('#stake')}); });
    $('#apostar').onclick = async () => {
      const m = Math.floor(+$('#stake').value);
      const e = !(m >= 100) ? 'El monto mínimo es $100.' : m > user.saldo ? 'No tenés saldo. Depositá para apostar.' : '';
      $('#berr').textContent = e; if (e) return;
      const txt = boleto.map(b => b.txt).join(' + ');
      $('#apostar').disabled = true;
      const r = await api('juego', {accion: 'deportes', monto: m, detalle: txt});
      if (!r.ok) { $('#berr').textContent = r.error || 'No se pudo registrar la apuesta.'; $('#apostar').disabled = false; return; }
      setSaldo(r.saldo);
      if ($('#share').checked) { const p = rd('popi_posts2', POSTS0); p.unshift({u: user.nombre + ' ' + user.apellido[0] + '.', t: 'recién', txt, q: +q.toFixed(2), m, likes: 0}); wr('popi_posts2', p); }
      boleto.length = 0; pintar(); pintarBol(); toast('Apuesta registrada');
    };
  };
  $('#filtros').onclick = e => { const b = e.target.closest('.chip'); if (!b) return; filtro = b.dataset.f; $$('#filtros .chip').forEach(x => x.setAttribute('aria-pressed', x === b)); pintar(); };
  $('#evs').onclick = e => {
    const o = e.target.closest('.odd'); if (!o) return;
    const i = +o.dataset.i, mk = o.dataset.mk, p = PART[i], pos = boleto.findIndex(b => b.i === i);
    const was = pos >= 0 && boleto[pos].mk === mk;
    if (pos >= 0) boleto.splice(pos, 1);
    if (!was) {
      const q = {'1': p.q[0], 'X': p.q[1], '2': p.q[2], 'O': p.ou[0], 'U': p.ou[1]}[mk];
      const txt = {'1': `${p.l} gana`, 'X': `Empate ${p.l}-${p.v}`, '2': `${p.v} gana`, 'O': `Más de 2,5 goles (${p.l}-${p.v})`, 'U': `Menos de 2,5 goles (${p.l}-${p.v})`}[mk];
      boleto.push({i, mk, q, txt});
    }
    pintar(); pintarBol();
  };
  pintar(); pintarBol();
}

function vistaSocial() {
  const posts = rd('popi_posts2', POSTS0), liked = rd('popi_likes', {});
  root().innerHTML = `<header><h1>Social</h1><p class="sub">Apuestas que comparte la comunidad. Para publicar la tuya, marcá “Compartir en Social” al apostar.</p></header>
  <div class="feed">${posts.map((p, i) => `<article class="post"><header><span class="av">${esc(p.u[0])}</span><div><strong>${esc(p.u)}</strong><small>${esc(p.t)}</small></div></header>
    <div class="slip"><span>${esc(p.txt)}</span><b>x${p.q}</b></div><div class="row"><span>Apostó ${fmt(p.m)}</span><span>Ganancia posible ${fmt(p.m * p.q)}</span></div>
    <div class="acts"><button class="btn ghost sm" data-like="${i}">${liked[i] ? 'Te gusta' : 'Me gusta'} (${p.likes + (liked[i] ? 1 : 0)})</button><a class="btn ghost sm" style="text-decoration:none" href="deportes.html">Ver partidos</a></div></article>`).join('')}</div>`;
  root().onclick = e => { const b = e.target.closest('[data-like]'); if (!b) return; liked[b.dataset.like] = !liked[b.dataset.like]; wr('popi_likes', liked); vistaSocial(); };
}

function vistaInicio() {
  const fila = (cat, nombre) => `<h2>${nombre}</h2><div class="rowh">${window.PopiJuegos[cat].map(j => cardJuego(cat, j)).join('')}</div>`;
  root().innerHTML = `<header><h1>Hola, ${esc(user.nombre)}</h1><p class="sub">Elegí dónde jugar. Tu saldo está siempre arriba a la derecha.</p></header>
    <div class="cats">${[['deportes','Apuestas deportivas','Champions, Liga Argentina, finales de Copa y fecha FIFA.'],['slots','Slots','Rodillos, bonus y jackpots.'],['arcade','Arcade','Memoria de pares, Mina segura y Crash Rocket.'],['casino','Casino','Blackjack, Cuentas rápidas y Pollo en la avenida.'],['social','Social','Compartí y mirá apuestas de otros.']].map(([id, n, d]) => `<a class="cat" href="${id}.html"><h3>${n}</h3><p>${d}</p></a>`).join('')}</div>
    ${fila('casino', 'Casino')}${fila('arcade', 'Arcade')}`;
}

const TIPO_MOV = {deposito: 'Depósito', retiro: 'Retiro', apuesta: 'Apuesta', premio: 'Premio', deportes: 'Deportes'};
let pollingCuenta = 0;
async function vistaCuenta() {
  clearTimeout(pollingCuenta);
  const r = await api('sesion', {completo: true});
  if (!r.ok) { if (r.sesion === false) location.replace('Popicasino.html'); return; }
  user = r.usuario; setSaldo(user.saldo);
  const mov = r.movimientos || [], tx = r.transacciones || [];
  root().innerHTML = `<header><h1>Mi cuenta</h1></header>
  <section class="panel"><div class="bal"><div><small>Saldo disponible</small><b>${fmt(user.saldo)}</b></div>
    <div class="btns"><button class="btn" id="d">Depositar</button><button class="btn ghost" id="r">Retirar</button></div></div></section>
  <h2>Transacciones</h2>
  ${tx.length ? `<div class="tabla-wrap"><table class="tabla"><thead><tr><th>Fecha</th><th>Tipo</th><th>Medio</th><th>Comprobante</th><th>Monto</th><th>Estado</th></tr></thead><tbody>
    ${tx.map(t => `<tr><td>${fechaHora(t.creado)}</td><td>${t.tipo === 'deposito' ? 'Depósito' : 'Retiro'}</td><td>${esc(NOM_METODO[t.metodo] || t.metodo)}</td><td>${esc(t.codigo)}</td><td class="${t.tipo === 'deposito' ? 'pos' : 'neg'}">${t.tipo === 'deposito' ? '+' : '−'}${fmt(t.monto)}</td><td><span class="est ${esc(t.estado)}">${esc(t.estado)}</span></td></tr>`).join('')}</tbody></table></div>` : '<p class="sub">Todavía no hiciste depósitos ni retiros.</p>'}
  <h2>Movimientos</h2>
  ${mov.length ? `<ul class="mov">${mov.map(m => `<li><span>${esc(m.txt)}<small>${TIPO_MOV[m.tipo] || esc(m.tipo)} · ${fechaHora(m.f)}</small></span><b class="${m.monto > 0 ? 'pos' : 'neg'}">${m.monto > 0 ? '+' : ''}${fmt(m.monto)}</b></li>`).join('')}</ul>` : '<p class="sub">Todavía no hay movimientos. Depositá para empezar.</p>'}
  <h2>Datos</h2><p class="sub">${esc(user.nombre)} ${esc(user.apellido)}, ${esc(user.email)}<br>Tu contraseña se guarda encriptada (hash bcrypt): nadie puede verla en la base de datos.</p>
  <p><button class="btn ghost sm" id="out">Cerrar sesión</button></p>`;
  $('#d').onclick = () => cajero('Depositar'); $('#r').onclick = () => cajero('Retirar'); $('#out').onclick = Popi.salir;
  const pie = document.createElement('footer'); pie.className = 'foot'; pie.textContent = TEXTO_PIE; root().append(pie);
  // Los retiros "procesando" se completan solos: se vuelve a consultar hasta que terminen
  if (tx.some(t => t.estado === 'procesando') && page === 'cuenta') pollingCuenta = setTimeout(vistaCuenta, 5000);
}

const TEXTO_PIE = 'Proyecto escolar de demostración: las fichas son virtuales y no se usa dinero real. Si el juego deja de ser un juego, pedí ayuda. Solo mayores de 18 años.';
const VISTAS = {inicio: vistaInicio, deportes: vistaDeportes, social: vistaSocial, cuenta: vistaCuenta,
  slots: lobbySlots, arcade: () => vistaJuegos('arcade'), casino: () => vistaJuegos('casino')};

(async () => {
  const r = await api('sesion');
  if (!r.ok) {
    if (r.red) { document.body.innerHTML = `<div class="wrap"><h1 class="logo" style="font-size:48px">Popicasino</h1><p class="estado mal" style="max-width:560px;margin:30px auto">${esc(r.error)}</p></div>`; return; }
    location.replace('Popicasino.html'); return;
  }
  user = r.usuario; shell();
  await (VISTAS[page] || VISTAS.inicio)();
  if (page !== 'cuenta' && page !== 'casino' && page !== 'arcade') {
    const pie = document.createElement('footer'); pie.className = 'foot'; pie.textContent = TEXTO_PIE; root().append(pie);
  }
})();
})();
