-- =====================================================================
--  POPICASINO - Base de datos (MySQL / MariaDB, para XAMPP en localhost)
--  Importar desde phpMyAdmin (pestaña "Importar") o desde la consola:
--      mysql -u root < sql/popicasino.sql
--  Proyecto escolar de demostración: no se mueve dinero real.
-- =====================================================================

CREATE DATABASE IF NOT EXISTS popicasino
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE popicasino;

-- ---------------------------------------------------------------------
--  USUARIOS
--  La contraseña NUNCA se guarda en texto plano: password_hash guarda el
--  resultado de password_hash() de PHP (bcrypt, con sal incluida).
--  Es un hash de una sola vía: ni siquiera quien administra la base de
--  datos puede ver la contraseña original. Al iniciar sesión, PHP usa
--  password_verify() para comprobar que coincide.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS usuarios (
  id            INT UNSIGNED  NOT NULL AUTO_INCREMENT,
  nombre        VARCHAR(60)   NOT NULL,
  apellido      VARCHAR(60)   NOT NULL,
  dni           VARCHAR(8)    NOT NULL,
  fecha_nac     DATE          NOT NULL,
  email         VARCHAR(120)  NOT NULL,
  password_hash VARCHAR(255)  NOT NULL,
  saldo         BIGINT        NOT NULL DEFAULT 0,      -- en pesos enteros
  creado        DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_usuarios_email (email),
  UNIQUE KEY uq_usuarios_dni   (dni),
  CONSTRAINT ck_saldo_no_negativo CHECK (saldo >= 0)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
--  MOVIMIENTOS: historial de todo lo que sube o baja el saldo
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS movimientos (
  id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  usuario_id    INT UNSIGNED    NOT NULL,
  tipo          VARCHAR(20)     NOT NULL,   -- deposito, retiro, apuesta, premio, deportes
  detalle       VARCHAR(200)    NOT NULL,
  monto         BIGINT          NOT NULL,   -- positivo suma, negativo resta
  saldo_despues BIGINT          NOT NULL,
  creado        DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY ix_mov_usuario (usuario_id, id),
  CONSTRAINT fk_mov_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
--  RONDAS: cada partida de casino / arcade (apuesta y premio)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS rondas (
  id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  usuario_id    INT UNSIGNED    NOT NULL,
  juego         VARCHAR(20)     NOT NULL,   -- blackjack, cuentas, pollo, memoria, minas, crash
  apuesta       BIGINT          NOT NULL,
  pago          BIGINT          NOT NULL DEFAULT 0,
  estado        ENUM('abierta','cerrada') NOT NULL DEFAULT 'abierta',
  creado        DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  cerrado       DATETIME        NULL,
  PRIMARY KEY (id),
  KEY ix_rondas_usuario (usuario_id, id),
  CONSTRAINT fk_rondas_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
--  TRANSACCIONES: depósitos y retiros (simulados)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS transacciones (
  id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  usuario_id    INT UNSIGNED    NOT NULL,
  tipo          ENUM('deposito','retiro') NOT NULL,
  metodo        VARCHAR(30)     NOT NULL,   -- transferencia, billetera, tarjeta
  monto         BIGINT          NOT NULL,
  destino       VARCHAR(40)     NULL,       -- CBU/CVU o alias (solo retiros)
  codigo        VARCHAR(20)     NOT NULL,   -- comprobante
  estado        ENUM('acreditado','procesando','completado','rechazado') NOT NULL,
  creado        DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_trans_codigo (codigo),
  KEY ix_trans_usuario (usuario_id, id),
  CONSTRAINT fk_trans_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
--  PARA MOSTRAR EN LA PRESENTACIÓN (phpMyAdmin > pestaña SQL):
--  Ver que la contraseña NO se puede leer (aparece el hash bcrypt, "$2y$10$..."):
--      SELECT id, nombre, email, password_hash, saldo FROM usuarios;
--  Ver depósitos y retiros:
--      SELECT * FROM transacciones ORDER BY id DESC;
--  Ver las partidas jugadas (juego, apuesta y premio):
--      SELECT * FROM rondas ORDER BY id DESC;
-- ---------------------------------------------------------------------
