/* Popicasino: partidos de fútbol y cuotas (datos de ejemplo para la presentación).
   - Fechas y horarios: fixtures confirmados al 12/11/2026 (horario de Argentina, GMT-3).
   - Cuotas: tomadas como referencia de casas de apuestas cuando se encontraron
     (Argentina vs Uruguay: Bet365/Paf; Real Madrid vs PSV: probabilidad de mercado)
     y estimadas con el mismo criterio para el resto. NO son cuotas reales ni se paga dinero real.
   - q = [Local, Empate, Visitante] al final de los 90 minutos.  ou = [Más de 2,5 goles, Menos de 2,5 goles]. */
window.COMPETENCIAS = [
  {id: 'champions', n: 'Champions League', sub: 'Fase de liga · Fecha 5 (martes 24 y miércoles 25 de noviembre)'},
  {id: 'liga', n: 'Liga Argentina · Playoffs', sub: 'Torneo Clausura 2026 (2º semestre) · Octavos de final, partido único'},
  {id: 'libertadores', n: 'Copa Libertadores', sub: 'Gran final · Estadio Centenario, Montevideo'},
  {id: 'sudamericana', n: 'Copa Sudamericana', sub: 'Gran final · Metropolitano Roberto Meléndez, Barranquilla'},
  {id: 'nations', n: 'Nations League (UEFA)', sub: 'Liga A · Fechas 5 y 6 (del 12 al 17 de noviembre)'},
  {id: 'amistosos', n: 'Amistosos · Fecha FIFA', sub: 'Del 12 al 17 de noviembre de 2026'}
];

const P = (comp, fecha, hora, l, v, q, ou, sede) => ({comp, fecha, hora, l, v, q, ou: ou || [1.9, 1.9], sede: sede || ''});

window.PARTIDOS = [
  /* ---- Champions League: fecha 5 ---- */
  P('champions', '2026-11-24', '14:45', 'Bodø/Glimt', 'LASK', [1.85, 3.6, 4.1], [1.8, 2.0]),
  P('champions', '2026-11-24', '14:45', 'Galatasaray', 'Aston Villa', [2.9, 3.4, 2.45], [1.75, 2.05]),
  P('champions', '2026-11-24', '17:00', 'Arsenal', 'Borussia Dortmund', [1.55, 4.4, 5.5], [1.6, 2.3]),
  P('champions', '2026-11-24', '17:00', 'Como', 'AEK Atenas', [2.0, 3.5, 3.6], [1.9, 1.9]),
  P('champions', '2026-11-24', '17:00', 'Feyenoord', 'Porto', [2.7, 3.4, 2.6], [1.85, 1.95]),
  P('champions', '2026-11-24', '17:00', 'Manchester City', 'Napoli', [1.5, 4.6, 5.6], [1.6, 2.3]),
  P('champions', '2026-11-24', '17:00', 'RB Leipzig', 'Lens', [1.95, 3.7, 3.7], [1.65, 2.2]),
  P('champions', '2026-11-24', '17:00', 'Real Madrid', 'PSV Eindhoven', [1.25, 7.0, 10.5], [1.5, 2.5]),
  P('champions', '2026-11-24', '17:00', 'Slovan Bratislava', 'Real Betis', [4.6, 3.8, 1.75], [1.9, 1.9]),
  P('champions', '2026-11-25', '14:45', 'Sabah', 'Barcelona', [11.0, 6.5, 1.22], [1.45, 2.65]),
  P('champions', '2026-11-25', '14:45', 'Slavia Praha', 'Villarreal', [2.6, 3.4, 2.7], [1.9, 1.9]),
  P('champions', '2026-11-25', '17:00', 'Atlético de Madrid', 'Viking', [1.4, 4.8, 7.5], [1.8, 2.0]),
  P('champions', '2026-11-25', '17:00', 'Club Brujas', 'Liverpool', [4.2, 3.9, 1.75], [1.6, 2.3]),
  P('champions', '2026-11-25', '17:00', 'Inter', 'Stuttgart', [1.6, 4.2, 5.2], [1.7, 2.1]),
  P('champions', '2026-11-25', '17:00', 'Shakhtar Donetsk', 'Fenerbahçe', [2.9, 3.4, 2.4], [1.85, 1.95]),
  P('champions', '2026-11-25', '17:00', 'Lille', 'Bayern Múnich', [4.8, 4.2, 1.6], [1.45, 2.65]),
  P('champions', '2026-11-25', '17:00', 'París Saint-Germain', 'Roma', [1.45, 4.8, 6.5], [1.6, 2.3]),
  P('champions', '2026-11-25', '17:00', 'Sporting CP', 'Manchester United', [2.3, 3.5, 3.0], [1.7, 2.1]),

  /* ---- Liga Argentina: octavos de final del Clausura (si hay empate: prórroga y penales) ---- */
  P('liga', '2026-11-20', '20:00', 'Vélez', 'Belgrano', [1.8, 3.2, 4.6], [2.2, 1.65]),
  P('liga', '2026-11-21', '15:00', 'Defensa y Justicia', 'Barracas Central', [2.2, 2.95, 3.7], [2.3, 1.6]),
  P('liga', '2026-11-21', '17:00', 'Argentinos Juniors', 'Independiente', [2.35, 3.0, 3.3], [2.2, 1.65]),
  P('liga', '2026-11-22', '16:00', 'Rosario Central', 'Gimnasia (Mendoza)', [1.7, 3.4, 5.2], [2.1, 1.7]),
  P('liga', '2026-11-22', '19:00', 'River Plate', 'Lanús', [1.9, 3.3, 4.2], [2.15, 1.68]),
  P('liga', '2026-11-22', '22:00', 'Instituto', 'Huracán', [2.5, 3.0, 3.2], [2.2, 1.65], 'Estadio Mario Alberto Kempes'),
  P('liga', '2026-11-23', '17:00', 'Gimnasia (La Plata)', 'Newell\'s', [2.45, 3.0, 3.2], [2.25, 1.62]),
  P('liga', '2026-11-25', '21:00', 'Boca Juniors', 'Independiente Rivadavia', [1.75, 3.3, 4.9], [2.2, 1.65]),

  /* ---- Finales de Copa ---- */
  P('sudamericana', '2026-11-21', '19:30', 'Atlético Mineiro', 'Boca Juniors', [2.45, 3.1, 2.9], [2.1, 1.7], 'Barranquilla, Colombia'),
  P('libertadores', '2026-11-28', '', 'Palmeiras', 'Estudiantes', [1.85, 3.3, 4.6], [2.25, 1.62], 'Montevideo, Uruguay · horario a confirmar'),

  /* ---- Nations League (UEFA, Liga A) ---- */
  P('nations', '2026-11-12', '14:00', 'Türkiye', 'Bélgica', [3.2, 3.4, 2.15], [1.7, 2.1]),
  P('nations', '2026-11-12', '16:45', 'Italia', 'Francia', [3.7, 3.5, 2.0], [2.1, 1.7]),
  P('nations', '2026-11-12', '16:45', 'Chequia', 'España', [7.0, 4.6, 1.4], [1.75, 2.05]),
  P('nations', '2026-11-12', '16:45', 'Inglaterra', 'Croacia', [1.65, 3.9, 5.2], [2.0, 1.8]),
  P('nations', '2026-11-13', '16:45', 'Países Bajos', 'Grecia', [1.55, 4.2, 5.8], [1.7, 2.1]),
  P('nations', '2026-11-13', '16:45', 'Serbia', 'Alemania', [4.5, 4.0, 1.7], [1.55, 2.4]),
  P('nations', '2026-11-14', '14:00', 'Noruega', 'Gales', [1.55, 4.2, 5.8], [1.6, 2.3]),
  P('nations', '2026-11-14', '16:45', 'Portugal', 'Dinamarca', [1.8, 3.7, 4.3], [2.0, 1.8]),
  P('nations', '2026-11-15', '16:45', 'Bélgica', 'Italia', [2.35, 3.4, 3.05], [1.75, 2.05]),
  P('nations', '2026-11-15', '16:45', 'Francia', 'Türkiye', [1.3, 5.6, 9.5], [1.65, 2.2]),
  P('nations', '2026-11-15', '16:45', 'Croacia', 'Chequia', [1.6, 4.0, 5.4], [2.1, 1.7]),
  P('nations', '2026-11-15', '16:45', 'España', 'Inglaterra', [1.95, 3.7, 3.6], [1.95, 1.85]),
  P('nations', '2026-11-16', '16:45', 'Alemania', 'Países Bajos', [2.2, 3.6, 3.1], [1.6, 2.3]),
  P('nations', '2026-11-16', '16:45', 'Grecia', 'Serbia', [2.6, 3.3, 2.8], [2.2, 1.65]),
  P('nations', '2026-11-17', '16:45', 'Dinamarca', 'Noruega', [2.4, 3.5, 2.9], [1.8, 2.0]),
  P('nations', '2026-11-17', '16:45', 'Gales', 'Portugal', [7.5, 4.8, 1.38], [1.75, 2.05]),

  /* ---- Amistosos de la fecha FIFA ---- */
  P('amistosos', '2026-11-13', '20:00', 'Argentina', 'Uruguay', [1.57, 4.0, 6.0], [2.2, 1.65], 'La Bombonera, Buenos Aires'),
  P('amistosos', '2026-11-13', '21:00', 'Ecuador', 'Costa Rica', [1.6, 3.8, 5.8], [2.1, 1.7], 'Quito'),
  P('amistosos', '2026-11-13', '21:00', 'Colombia', 'Chile', [1.95, 3.2, 4.1], [2.2, 1.65]),
  P('amistosos', '2026-11-14', '07:15', 'Japón', 'Brasil', [3.6, 3.5, 2.05], [1.85, 1.95]),
  P('amistosos', '2026-11-17', '20:00', 'Argentina', 'Costa Rica', [1.12, 8.5, 20.0], [1.55, 2.45], 'Estadio Kempes, Córdoba'),
  P('amistosos', '2026-11-17', '20:00', 'Chile', 'Colombia', [3.6, 3.3, 2.05], [2.2, 1.65]),
  P('amistosos', '2026-11-17', '20:30', 'Ecuador', 'Bolivia', [1.5, 4.0, 6.5], [1.95, 1.85], 'Guayaquil')
];
